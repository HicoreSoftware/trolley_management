﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using RestAPIConnection;

namespace TrolleyClient
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //string EndPointAddress = "trolleyInventory";


            //List<Trolleyinventory> Trolleyinventory = new List<Trolleyinventory>()
            //{
            //    new Trolleyinventory(11,11,11,DateTime.Now,DateTime.Now),
            //    new Trolleyinventory(12,12,12,DateTime.Now,DateTime.Now),
            //    new Trolleyinventory(13,13,13,DateTime.Now,DateTime.Now),
            //    new Trolleyinventory(14,14,14,DateTime.Now,DateTime.Now),
            //    new Trolleyinventory(15,15,15,DateTime.Now,DateTime.Now),
            //    new Trolleyinventory(16,16,16,DateTime.Now,DateTime.Now),
            //    new Trolleyinventory(17,17,17,DateTime.Now,DateTime.Now),
            //    new Trolleyinventory(18,18,18,DateTime.Now,DateTime.Now),
            //};

            //foreach (var item in Trolleyinventory)
            //{
            //    string itemstring = item.GetJsonString();
            //    _ = RestApiConnection.Instance.AddDataSync(EndPointAddress, itemstring);

            //    Console.WriteLine(itemstring);

            //    Thread.Sleep(2000);
            //}

        }
    }
}
