﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrollyManagement.Commands;

namespace TrollyManageGUI.Models
{
    /// <summary>
    /// 
    /// </summary>
    public class TrolleyInventory : BaseViewModel
    {


        public TrolleyInventory()
        {
			TrolleyID = "1";
			ScannerID = "1";
			RoomID = "1";
			InTime = DateTime.Now;
			Status = "In";
        }

        public TrolleyInventory(string json)
        {

        }
        #region Properties 
        private string scannerID;

		/// <summary>
		/// 
		/// </summary>
		public string ScannerID
		{
			get 
			{ 
				return scannerID; 
			}
			set 
			{ 
				scannerID = value; 
				OnPropertyChanged(nameof(ScannerID)); 
			}
		}

		private string roomID;

		public string RoomID
		{
			get { return roomID; }
			set { roomID = value; OnPropertyChanged("RoomID"); }
		}

		private string trolleyID;

		public string TrolleyID
		{
			get { return trolleyID; }
			set { trolleyID = value; OnPropertyChanged("TrolleyID"); }
		}

		private DateTime? inTime;

		public DateTime? InTime
		{
			get { return inTime; }
			set { inTime = value; OnPropertyChanged("InTime"); }
		}

		private DateTime? outTime;

		public DateTime? OutTime
		{
			get { return outTime; }
			set { outTime = value; OnPropertyChanged("OutTime"); }
		}

		private string status;

		public string Status
		{
			get { return status; }
			set { status = value; OnPropertyChanged("Status"); }
		}
        #endregion 


    }
}
