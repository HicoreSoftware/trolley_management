﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrollyManagement.Commands;

namespace TrollyManageGUI.Models
{
    public class Trolley : BaseViewModel
    {
		public Trolley()
		{
			TrolleyID = 1;
			PurchaseDate = DateTime.Now;
			LastMaintenanceDate = DateTime.Now;
		}

		private int trolleyID;

		public int TrolleyID
		{
			get { return trolleyID; }
			set { trolleyID = value; OnPropertyChanged("TrolleyID"); }
		}

		private DateTime purchaseDate;

		public DateTime PurchaseDate
		{
			get { return purchaseDate; }
			set { purchaseDate = value; OnPropertyChanged("PurchaseDate"); }
		}

		private DateTime lastMaintenanceDate;

		public DateTime LastMaintenanceDate
		{
			get { return lastMaintenanceDate; }
			set { lastMaintenanceDate = value; OnPropertyChanged("LastMaintenanceDate"); }
		}



	}
}
