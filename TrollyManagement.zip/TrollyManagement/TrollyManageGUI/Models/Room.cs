﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrollyManagement.Commands;

namespace TrollyManageGUI.Models
{
    /// <summary>
    /// This class Room is used to store room infomation 
    /// </summary>
    public class Room : BaseViewModel
    {
        /// <summary>
        /// 
        /// </summary>
        public Room()
		{
			RoomID = 1;
			ScannerID = 1;
			Name = "Room1";
			Min = 10;
			Max = 100;
        }

        private int scannerID;
		public int ScannerID
		{
			get { return scannerID; }
			set { scannerID = value; OnPropertyChanged("ScannerID"); }
		}

		private int roomID;
		public int RoomID
		{
			get { return roomID; }
			set { roomID = value; OnPropertyChanged("RoomID"); }
		}

		private string name;

		public string Name
		{
			get { return name; }
			set { name = value; OnPropertyChanged("Name"); }
		}

		private int min;

		public int Min
		{
			get { return min; }
			set { min = value; OnPropertyChanged("Min"); }
		}

		private int max;

		public int Max
		{
			get { return max; }
			set { max = value; OnPropertyChanged("Max"); }
		}
	}
}
