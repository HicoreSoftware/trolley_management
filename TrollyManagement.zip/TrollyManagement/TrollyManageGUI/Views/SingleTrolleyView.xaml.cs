﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TrollyManageGUI.ViewModels;

namespace TrollyManageGUI.Views
{
    /// <summary>
    /// Interaction logic for SingleTrolleyView.xaml
    /// </summary>
    public partial class SingleTrolleyView : Window
    {
        public SingleTrolleyViewModel SingleTrolleyViewModel = new SingleTrolleyViewModel();
        public SingleTrolleyView()
        {
            InitializeComponent();
            this.DataContext = SingleTrolleyViewModel;
        }
        
    }
}
