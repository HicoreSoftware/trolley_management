﻿using Newtonsoft.Json;
using RestAPIConnection;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using TrollyManageGUI.Models;
using TrollyManageGUI.Views;
using TrollyManagement.Commands;


namespace TrollyManageGUI.ViewModels
{

    public class TrolleyInventryManagementViewModel : BaseViewModel
    {
        private const string EndPointAddress = "trolleyInventory";
        public TrolleyInventryManagementViewModel()
        {
            saveCommand = new RelayCommand(Save);
            searchCommand = new RelayCommand(Search);
            updateCommand = new RelayCommand(Update);
            deleteCommand = new RelayCommand(Delete);
            LoadData();

            RestApiConnection.Instance.OnUpdateTrolleyInventry += OnUpdateTrolleyInfo;
        }

        public void OnUpdateTrolleyInfo(string trolleyJson)
        {
            App.Current.Dispatcher.Invoke(delegate
            {
                TrolleyInventryList.Clear();
                LoadData();
            });
        }

        private ObservableCollection<TrolleyInventory> trolleyInventryList;

        public ObservableCollection<TrolleyInventory> TrolleyInventryList
        {
            get 
            {
                return trolleyInventryList; 
            }
            set 
            {
                trolleyInventryList = value; OnPropertyChanged(nameof(TrolleyInventryList));
            }
        }

        private async void LoadData()
        {
            string jsonContent = await RestApiConnection.Instance.GetJsonStringAsync(EndPointAddress);

            if (!string.IsNullOrEmpty(jsonContent))
            {
                List<TrolleyInventory> trolleyInventry = JsonConvert.DeserializeObject<List<TrolleyInventory>>(jsonContent);
                TrolleyInventryList = new ObservableCollection<TrolleyInventory>(trolleyInventry);
            }
        }

        private TrolleyInventory selectedTrolleyInventryItem;

        public TrolleyInventory SelectedTrolleyInventryItem
        {
            get 
            {
                return selectedTrolleyInventryItem; 
            }
            set 
            {
                selectedTrolleyInventryItem = value; OnPropertyChanged(nameof(SelectedTrolleyInventryItem));
            }
        }

        private RelayCommand saveCommand;

        public RelayCommand SaveCommand
        {
            get { return saveCommand; }
        }

        public async void Save(object parameter)
        {
            try
            {
                SingleTrolleyInventryView singleTrolleyInventryView = new SingleTrolleyInventryView();
                singleTrolleyInventryView.ShowDialog();

                if (!singleTrolleyInventryView.SingleTrolleyInventryViewModel.success)
                    return;

                /*// Add In Time
                if (singleTrolleyInventryView.SingleTrolleyInventryViewModel.CurrentTrolleyInventry.InTime != null)
                {
                    singleTrolleyInventryView.SingleTrolleyInventryViewModel.CurrentTrolleyInventry.InTime = DateTime.Now;                    
                }*/
                singleTrolleyInventryView.SingleTrolleyInventryViewModel.CurrentTrolleyInventry.InTime = DateTime.Now;
                singleTrolleyInventryView.SingleTrolleyInventryViewModel.CurrentTrolleyInventry.OutTime = null;
                singleTrolleyInventryView.SingleTrolleyInventryViewModel.CurrentTrolleyInventry.Status = "In";
                


                string jsonTrolleyInventry = JsonConvert.SerializeObject(singleTrolleyInventryView.SingleTrolleyInventryViewModel.CurrentTrolleyInventry);

                await RestApiConnection.Instance.AddDataSync(EndPointAddress, jsonTrolleyInventry);

                TrolleyInventryList.Add(singleTrolleyInventryView.SingleTrolleyInventryViewModel.CurrentTrolleyInventry);

            }
            catch (Exception ex)
            {

            }
        }

        private string searchTrolleyID;

        public string SearchTrolleyID
        {
            get { return searchTrolleyID; }
            set { searchTrolleyID = value; OnPropertyChanged(nameof(SearchTrolleyID)); }
        }


        private RelayCommand searchCommand;

        public RelayCommand SearchCommand
        {
            get { return searchCommand; }            
        }

        public async void Search(object parameter)
        {
            try
            {
                string jsonContent = string.Empty;
                if (SearchTrolleyID != null)
                {
                    jsonContent = await RestApiConnection.Instance.GetJsonStringAsync(EndPointAddress + "/" + SearchTrolleyID);
                }
                else
                {
                    jsonContent = await RestApiConnection.Instance.GetJsonStringAsync(EndPointAddress);
                }

                if (!string.IsNullOrEmpty(jsonContent) && SearchTrolleyID!=null)
                {
                    List<TrolleyInventory> trolleyInventryData = JsonConvert.DeserializeObject<List<TrolleyInventory>>(jsonContent);

                    TrolleyInventryList = new ObservableCollection<TrolleyInventory>(trolleyInventryData.Where(data => data.Status.ToUpper() == "IN"));
                                                          
                }
                else
                {
                    List<TrolleyInventory> trolleyInventry = JsonConvert.DeserializeObject<List<TrolleyInventory>>(jsonContent);
                    TrolleyInventryList = new ObservableCollection<TrolleyInventory>((IEnumerable<TrolleyInventory>)trolleyInventry);
                }
            }
            catch (Exception ex)
            {

                
            }

        }

        private RelayCommand updateCommand;

        public RelayCommand UpdateCommand
        {
            get { return updateCommand; }
        }


        public async void Update(object parameter)
        {
            try
            {
                SingleTrolleyInventryView singleTrolleyInventryView = new SingleTrolleyInventryView();
                singleTrolleyInventryView.SingleTrolleyInventryViewModel.CurrentTrolleyInventry = SelectedTrolleyInventryItem;
                //singleTrolleyInventryView.ShowDialog();
                //if (!singleTrolleyInventryView.SingleTrolleyInventryViewModel.success)
                //    return;
                /*//Add Out Time
                if (singleTrolleyInventryView.SingleTrolleyInventryViewModel.CurrentTrolleyInventry.OutTime != null)
                {
                    singleTrolleyInventryView.SingleTrolleyInventryViewModel.CurrentTrolleyInventry.OutTime = DateTime.Now;
                }*/
                if (SelectedTrolleyInventryItem != null)
                {
                    singleTrolleyInventryView.SingleTrolleyInventryViewModel.CurrentTrolleyInventry.OutTime = DateTime.Now;
                    singleTrolleyInventryView.SingleTrolleyInventryViewModel.CurrentTrolleyInventry.Status = "Out";
                }
                
                string jsonTrolleyInventry = JsonConvert.SerializeObject(singleTrolleyInventryView.SingleTrolleyInventryViewModel.CurrentTrolleyInventry);
                if (jsonTrolleyInventry != "null") 
                {
                    await RestApiConnection.Instance.UpdateDataAsync(EndPointAddress, SelectedTrolleyInventryItem.TrolleyID.ToString(), jsonTrolleyInventry);                    
                    var updateTrolleyInventryList = TrolleyInventryList.FirstOrDefault(p => p.TrolleyID == SelectedTrolleyInventryItem.TrolleyID);
                    if (updateTrolleyInventryList != null)
                    {
                        updateTrolleyInventryList.OutTime = DateTime.Now;
                        updateTrolleyInventryList.Status = "Out";
                    }
                }

            }
            catch (Exception ex)
            {

            }
        }

        private RelayCommand deleteCommand;

        public RelayCommand DeleteCommand
        {
            get { return deleteCommand; }
        }

        public async void Delete(object parameter)
        {
            try
            {

                if (SelectedTrolleyInventryItem != null)
                {
                    await RestApiConnection.Instance.DeleteDataAsyc(EndPointAddress + "/" + SelectedTrolleyInventryItem.TrolleyID);
                    TrolleyInventryList.Remove(SelectedTrolleyInventryItem);
                }

            }
            catch (Exception ex)
            {

            }
        }



    }
}
