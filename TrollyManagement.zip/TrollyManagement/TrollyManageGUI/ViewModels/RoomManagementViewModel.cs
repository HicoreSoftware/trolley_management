﻿using Newtonsoft.Json;
using RestAPIConnection;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using TrollyManageGUI.Models;
using TrollyManageGUI.Views;
using TrollyManagement.Commands;

namespace TrollyManageGUI.ViewModels
{
    public class RoomManagementViewModel : BaseViewModel
    {

        private const string EndPointAddress = "room";
        public RoomManagementViewModel()
        {
            saveCommand = new RelayCommand(Save);
            updateCommand = new RelayCommand(Update);
            deleteCommand = new RelayCommand(Delete);
            LoadData();
        }

        private ObservableCollection<Room> roomList;

        public ObservableCollection<Room> RoomList
        {
            get { return roomList; }
            set { roomList = value; OnPropertyChanged("RoomList"); }
        }

        private async void LoadData()
        {
     

            string jsonContent = await RestApiConnection.Instance.GetJsonStringAsync("room");

            if(!string.IsNullOrEmpty(jsonContent))
            {
                List<Room> rooms = JsonConvert.DeserializeObject<List<Room>>(jsonContent);

                if(rooms != null)
                {
                    RoomList = new ObservableCollection<Room>(rooms);

                }


            }



        }

        private Room selectedRoomItem;

        public Room SelectedRoomItem
        {
            get { return selectedRoomItem; }
            set { selectedRoomItem = value; OnPropertyChanged("SelectedRoomItem"); }
        }


        private RelayCommand saveCommand;

        public RelayCommand SaveCommand
        {
            get { return saveCommand; }
        }

        public async void Save(object parameter)
        {
            try
            {
                SingleRoomView singleRoomView = new SingleRoomView();
                singleRoomView.ShowDialog();                                            
           
                if (!singleRoomView.SingleRoomViewModel.success)
                    return;

                string jsonRoom = JsonConvert.SerializeObject(singleRoomView.SingleRoomViewModel.CurrentRoom);

                await RestApiConnection.Instance.AddDataSync(EndPointAddress, jsonRoom);

                RoomList.Add(singleRoomView.SingleRoomViewModel.CurrentRoom);
    
            }
            catch (Exception ex)
            {
             
            }
        }


        private RelayCommand updateCommand;

        public RelayCommand UpdateCommand
        {
            get { return updateCommand; }
        }


        public async void Update(object parameter)
        {
            try
            {
                SingleRoomView singleRoomView = new SingleRoomView();
                singleRoomView.SingleRoomViewModel.CurrentRoom = SelectedRoomItem;
                singleRoomView.ShowDialog();
                if (!singleRoomView.SingleRoomViewModel.success)
                    return;

                string jsonRoom = JsonConvert.SerializeObject(singleRoomView.SingleRoomViewModel.CurrentRoom);
                if (jsonRoom != "null")
                {
                    await RestApiConnection.Instance.UpdateDataAsync(EndPointAddress, SelectedRoomItem.RoomID.ToString(), jsonRoom);
                }
                

            }
            catch (Exception ex)
            {

            }
        }

        private RelayCommand deleteCommand;

        public RelayCommand DeleteCommand
        {
            get { return deleteCommand; }
        }

        public async void Delete(object parameter)
        {
            try
            {
               if (SelectedRoomItem != null)
                {
                    await RestApiConnection.Instance.DeleteDataAsyc(EndPointAddress + "/" + SelectedRoomItem.RoomID);
                    RoomList.Remove(SelectedRoomItem);
                }             

            }
            catch (Exception ex)
            {
                
            }
        }
    }
}
