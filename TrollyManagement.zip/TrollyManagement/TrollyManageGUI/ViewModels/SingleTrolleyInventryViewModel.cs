﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using TrollyManageGUI.Models;
using TrollyManagement.Commands;

namespace TrollyManageGUI.ViewModels
{
    public class SingleTrolleyInventryViewModel : BaseViewModel
    {

        public bool success = false;
        public SingleTrolleyInventryViewModel()
        {
            success = false;
            currentTrolleyInventry = new TrolleyInventory();
            okCommand = new RelayCommand(Ok, param => true);
            cancelCommand = new RelayCommand(Cancel, param => true);
        }

        private TrolleyInventory currentTrolleyInventry;

        public TrolleyInventory CurrentTrolleyInventry
        {
            get 
            {
                return currentTrolleyInventry; 
            }
            set 
            {
                currentTrolleyInventry = value; OnPropertyChanged(nameof(CurrentTrolleyInventry));
            }
        }

        private RelayCommand okCommand;

        public RelayCommand OkCommand
        {
            get { return okCommand; }
        }

        public void Ok(object parameter)
        {
            success = true;
            Window wnd = (Window)parameter;
            wnd?.Close();
        }

        private RelayCommand cancelCommand;

        public RelayCommand CancelCommand
        {
            get { return cancelCommand; }
        }

        public void Cancel(object parameter)
        {
            Window wnd = (Window)parameter;
            wnd?.Close();
        }


    }
}
