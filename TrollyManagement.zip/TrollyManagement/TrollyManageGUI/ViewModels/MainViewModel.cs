﻿using Microsoft.VisualBasic;
using RestAPIConnection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrollyManagement.Commands;

namespace TrollyManageGUI.ViewModels
{
    public class MainViewModel : BaseViewModel
    {        

        public MainViewModel() 
        {
            changeRoomCommand = new RelayCommand(ChangeRoomView);
            changeTrolleyCommand = new RelayCommand(ChangeTrollView);
            changeTrolleyInventryCommand = new RelayCommand(ChangeTrollInventryView);
            SelectedViewModel = new RoomManagementViewModel();

            RestApiConnection.Instance.Connect();
        }

        private void ChangeRoomView(object parameter)
        {
            SelectedViewModel = new RoomManagementViewModel();
        }

        private void ChangeTrollView(object parameter)
        {
            SelectedViewModel = new TrolleyManagementViewModel();
        }

        private void ChangeTrollInventryView(object parameter)
        {
            SelectedViewModel = new TrolleyInventryManagementViewModel();

        }

        public BaseViewModel selectedViewMode;
             
       public BaseViewModel SelectedViewModel 
        { 
            get
            {
                return selectedViewMode;
            }
            set
            {
                selectedViewMode = value;
                OnPropertyChanged(nameof(SelectedViewModel));
            }
        }


        private RelayCommand changeRoomCommand;

        public RelayCommand ChangeRoomCommand
        {
            get { return changeRoomCommand; }
        }

        private RelayCommand changeTrolleyCommand;

        public RelayCommand ChangeTrolleyCommand
        {
            get { return changeTrolleyCommand; }
        }

        private RelayCommand changeTrolleyInventryCommand;

        public RelayCommand ChangeTrolleyInventryCommand
        {
            get { return changeTrolleyInventryCommand; }
        }


    }
}
