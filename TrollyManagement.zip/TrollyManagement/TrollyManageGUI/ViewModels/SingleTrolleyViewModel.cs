﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using TrollyManageGUI.Models;
using TrollyManagement.Commands;

namespace TrollyManageGUI.ViewModels
{
    public class SingleTrolleyViewModel : BaseViewModel
    {

        public bool success = false;
        public SingleTrolleyViewModel()
        {
            success = false;
            currentTrolley = new Trolley();
            okCommand = new RelayCommand(Ok, param => true);
            cancelCommand = new RelayCommand(Cancel, param => true);
        }

        private Trolley currentTrolley;

        public Trolley CurrentTrolley
        {
            get 
            {
                return currentTrolley; 
            }
            set 
            {
                currentTrolley = value; OnPropertyChanged(nameof(CurrentTrolley)); 
            }
        }


        private RelayCommand okCommand;

        public RelayCommand OkCommand
        {
            get { return okCommand; }
        }

        public void Ok(object parameter)
        {
            success = true;
            Window wnd = (Window)parameter;
            wnd?.Close();
        }

        private RelayCommand cancelCommand;

        public RelayCommand CancelCommand
        {
            get { return cancelCommand; }
        }

        public void Cancel(object parameter)
        {
            Window wnd = (Window)parameter;
            wnd?.Close();
        }


    }
}
