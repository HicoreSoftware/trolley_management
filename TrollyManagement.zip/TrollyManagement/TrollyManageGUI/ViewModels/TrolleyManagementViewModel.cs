﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using TrollyManagement.Commands;
using TrollyManageGUI.Models;
using Newtonsoft.Json;
using RestAPIConnection;
using TrollyManageGUI.Views;

namespace TrollyManageGUI.ViewModels
{
    public class TrolleyManagementViewModel : BaseViewModel
    {

        private const string EndPointAddress = "trolley";
        public TrolleyManagementViewModel()
        {
            saveCommand = new RelayCommand(Save);
            updateCommand = new RelayCommand(Update);
            deleteCommand = new RelayCommand(Delete);
            LoadData();
        }

        private ObservableCollection<Trolley> trolleyList;

        public ObservableCollection<Trolley> TrolleyList
        {
            get 
            {
                return trolleyList; 
            }
            set
            { 
                trolleyList = value; OnPropertyChanged(nameof(TrolleyList));
            }
        }


        private async void LoadData()
        {
            ///  RoomDB roomDB = new RoomDB();
            //   List<Room> rooms = await roomDB.GetRoomsAsync();

            string jsonContent = await RestApiConnection.Instance.GetJsonStringAsync("trolley");

            if (!string.IsNullOrEmpty(jsonContent))
            {
                List<Trolley> trolley = JsonConvert.DeserializeObject<List<Trolley>>(jsonContent);               
                TrolleyList = new ObservableCollection<Trolley>(trolley);
            }
        }

        private Trolley selectedTrolleyItem;

        public Trolley SelectedTrolleyItem
        {
            get 
            {
                return selectedTrolleyItem; 
            }
            set 
            {
                selectedTrolleyItem = value; OnPropertyChanged(nameof(SelectedTrolleyItem));
            }
        }

        private RelayCommand saveCommand;

        public RelayCommand SaveCommand
        {
            get { return saveCommand; }
        }

        public async void Save(object parameter)
        {
            try
            {
                SingleTrolleyView singleTrolleyView = new SingleTrolleyView();
                singleTrolleyView.ShowDialog();                                

                if (!singleTrolleyView.SingleTrolleyViewModel.success)
                    return;

                string jsonTrolley = JsonConvert.SerializeObject(singleTrolleyView.SingleTrolleyViewModel.CurrentTrolley);

                await RestApiConnection.Instance.AddDataSync(EndPointAddress, jsonTrolley);

                TrolleyList.Add(singleTrolleyView.SingleTrolleyViewModel.CurrentTrolley);

            }
            catch (Exception ex)
            {

            }
        }


        private RelayCommand updateCommand;

        public RelayCommand UpdateCommand
        {
            get { return updateCommand; }
        }


        public async void Update(object parameter)
        {
            try
            {
                SingleTrolleyView singleTrolleyView = new SingleTrolleyView();
                singleTrolleyView.SingleTrolleyViewModel.CurrentTrolley = SelectedTrolleyItem;
                singleTrolleyView.ShowDialog();
                if (!singleTrolleyView.SingleTrolleyViewModel.success)
                    return;

                string jsonTrolley = JsonConvert.SerializeObject(singleTrolleyView.SingleTrolleyViewModel.CurrentTrolley);
                if (jsonTrolley != "null")
                {
                    await RestApiConnection.Instance.UpdateDataAsync(EndPointAddress, SelectedTrolleyItem.TrolleyID.ToString(), jsonTrolley);
                }
                

            }
            catch (Exception ex)
            {

            }
        }

        private RelayCommand deleteCommand;

        public RelayCommand DeleteCommand
        {
            get { return deleteCommand; }
        }

        public async void Delete(object parameter)
        {
            try
            {
                if (SelectedTrolleyItem != null)
                {
                    await RestApiConnection.Instance.DeleteDataAsyc(EndPointAddress + "/" + SelectedTrolleyItem.TrolleyID);
                    TrolleyList.Remove(SelectedTrolleyItem);
                }

            }
            catch (Exception ex)
            {

            }
        }
    }
}
