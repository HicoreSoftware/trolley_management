﻿using ScannerData.ViewModels;
using Symbol.RFID.SDK.Domain.Reader;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ScannerData
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private IRfidReader selectedReader;

        public MainWindow()
        {
            InitializeComponent();
            TrolleyInventoryViewModel TrolleyInventoryViewModel = new TrolleyInventoryViewModel();
            // InitializeReaderWatcher();

            RFIDLibraryUtility.InitReaderList(ReaderCommunicationMode.Bluetooth);


            selectedReader.Inventory.TagDataReceived += Inventory_TagDataReceived;
        }

        private void Inventory_TagDataReceived(object sender, TagDataReceivedEventArgs e)
        {
            throw new NotImplementedException();
        }
    }
}
