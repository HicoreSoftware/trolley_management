﻿using Symbol.RFID.SDK;
using Symbol.RFID.SDK.Domain.Reader;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Input;

namespace ScannerData.ViewModels
{
    public class TrolleyInventoryViewModel
    {
        #region Private Fields

        private List<IRfidReader> readerList;
        private IRfidReader selectedReader;

        private RFIDReaderItem selectedItem;

        private Dictionary<string, TagInfo> tagList = new Dictionary<string, TagInfo>();

        private bool isStopPressed;
        private bool isConnected;

        private bool isConnectedManually = false;

        private bool isBluetoothWatcherInitialized = false;
        
        private bool isAccessSequenceOperationInProgress = false;

        private string deviceIdWhichRunsInventory = string.Empty;
        private string deviceIdWhichRunsTagLocate = string.Empty;

        //   private System.Windows.Forms.Timer deviceStatusTimer;

        #endregion

        #region Constructors

        public TrolleyInventoryViewModel()
        {
            // InitializeComponent();
            try
            {
                InitializeReaderWatcher();
            }
            catch (Exception ex)
            {
                //Print exception to log if Initializing ReaderWatcher failed
                //OutputText(ex.Message);
                //Disable controls
                //DisableControls();
            }
        }

        #endregion

        /// <summary>
        /// Initialize the reader watcher events.
        /// </summary>
        private void InitializeReaderWatcher()
        {
            // Bluetooth Connectivity
            try
            {
                IRemoteReaderWatcher remoteReaderWatcher = RfidSdk.ReaderWatcherServicesFactory.Create(ReaderCommunicationMode.Bluetooth);
                //remoteReaderWatcher.ReaderAppeared += new EventHandler<ReaderStatusChangedEventArgs>(ReaderAppearedHandler);
                //remoteReaderWatcher.ReaderDisappeared += new EventHandler<ReaderStatusChangedEventArgs>(ReaderDisappearedHandler);
                //remoteReaderWatcher.ReaderConnected += new EventHandler<ReaderStatusChangedEventArgs>(ReaderConnectedHandler);
                //remoteReaderWatcher.ReaderDisconnected += new EventHandler<ReaderStatusChangedEventArgs>(ReaderDisconnectedHandler);

                isBluetoothWatcherInitialized = true;
            }
            catch (Exception ex)
            {
                //Print exception to log if Initializing ReaderWatcher failed
                //OutputText(ex.Message);
            }
        }

        /// <summary>
        /// Fill reader items into home screen reader comboBox.
        /// </summary>
        private void FillRFIDReadersItems()
        {
            //Cursor.Current = Cursors.WaitCursor;
            try
            {
                readerList = new List<IRfidReader>();
                //comboBoxReaders.Items.Clear();

                //Initialize reader management and reader info list.
                var readerInfoList = new List<IRfidReaderInfo>();

                if (isBluetoothWatcherInitialized)
                {
                    var remoteReaderInfoList = RFIDLibraryUtility.InitReaderList(ReaderCommunicationMode.Bluetooth);
                    readerInfoList.AddRange(remoteReaderInfoList);
                }
            }
            catch (Exception ex)
            {
                //OutputText("Error discovering scanner: " + ex.Message);
            }
            //Cursor.Current = Cursors.Default;
        }

        /// <summary>
        /// Connect the selected reader.
        /// </summary>
        private void Connect(RFIDReaderItemInfo deviceInfo)
        {
            try
            {
                SetSelectedReader();

                if (selectedReader.IsConnected)
                {
                    RFIDLibraryUtility.Disconnect(selectedReader);
                }

                Thread connectThread = new Thread(() => StartConnect(deviceInfo));
                connectThread.Start();
                                
            }
            catch (Exception ex)
            {
                //OutputText(ex.Message);
                //Cursor.Current = Cursors.Default;
            }
        }

        private void SetSelectedReader()
        {
            // selectedItem = (RFIDReaderItem)comboBoxReaders.SelectedItem;

            string selectedItemID = "";
            selectedReader = readerList.Find(i => i.ID.Equals(selectedItemID, StringComparison.OrdinalIgnoreCase));

            if (selectedReader == null)
            {
                throw new ApplicationException("Selected reader should not be null.");
            }
        }

        /// <summary>
        /// Initiates a connection to the reader. 
        /// </summary>
        private void StartConnect(RFIDReaderItemInfo deviceInfo)
        {
            try
            {
                selectedReader.Inventory.AttachTagDataWithTagDataReceivedEvent = true;

                RFIDLibraryUtility.Connect(selectedReader);

            }
            catch (Exception ex)
            {
               
            }
        }

        /// <summary>
        /// Starts the inventory.
        /// </summary>
        private void StartInventory()
        {
            try
            {
                if (ActiveReaderStatus.IsInventoryRunning)
                {
                    //OutputText("Inventory perform already in progress....");
                }
                else
                {
                    // Clean the inventory tag data list
               //     ResetTagInfo();

                    isStopPressed = false;
                    deviceIdWhichRunsInventory = selectedReader.ID;
                    ActiveReaderStatus.IsInventoryRunning = true;

                    Task.Run(new Action(delegate
                    {
                        try
                        {
                            RFIDLibraryUtility.InventoryPerfom(selectedReader);
                        }
                        catch (Exception ex)
                        {
                            deviceIdWhichRunsInventory = string.Empty;
                            ActiveReaderStatus.IsInventoryRunning = false;

                            //Invoke((MethodInvoker)delegate
                            //{
                            //    OutputText(ex.Message);
                            //});
                        }
                       // UpdateInventoryButtons();
                    }));

                    if (ActiveReaderStatus.BatchMode == BATCH_MODE.ENABLE)
                    {
                        //BeginInvoke(new Action(delegate
                        //{
                        //    OutputText("Inventory is running in batch mode...");
                        //}));
                        ActiveReaderStatus.IsBatchModeInventoryRunning = true;
                    }
                }
            }
            catch (InvalidOperationException ex)
            {
                // While reader is in a busy state from a previous inventory session, if the user attempts to start a new inventory session, the following exceptions is thrown. 
                if (ex.Message.Contains("Unknown read session is in place"))
                {
                    //DialogResult result = System.Windows.MessageBox.Show("Unknown inventory is running(in batch mode). Click 'Inventory Stop'",
                    //                                      "Important",
                    //                                      MessageBoxButtons.OK,
                    //                                      MessageBoxIcon.Information,
                    //                                      MessageBoxDefaultButton.Button2);

                    ActiveReaderStatus.IsBatchModeInventoryRunning = (ActiveReaderStatus.BatchMode != BATCH_MODE.DISABLE);

                    deviceIdWhichRunsInventory = selectedReader.ID;
                    ActiveReaderStatus.IsInventoryRunning = true;

                  //  UpdateInventoryButtons();
                }
            }
            catch (Exception ex)
            {
                deviceIdWhichRunsInventory = string.Empty;
                ActiveReaderStatus.IsInventoryRunning = false;

                //UpdateInventoryButtons();
                //OutputText(ex.Message);
            }
        }

        /// <summary>
        /// Stops the inventory.
        /// </summary>
        private void StopInventory()
        {
            try
            {
                if (ActiveReaderStatus.IsInventoryRunning)
                {
                    isStopPressed = true;

                    RFIDLibraryUtility.StopInventory(selectedReader);

                    if (ActiveReaderStatus.IsBatchModeInventoryRunning)
                    {
                        RFIDLibraryUtility.GetBatchedTags(selectedReader);
                       // OutputText("Get Batched Tags : Successful");
                        ActiveReaderStatus.IsBatchModeInventoryRunning = false;
                    }

                    deviceIdWhichRunsInventory = string.Empty;
                    ActiveReaderStatus.IsInventoryRunning = false;
                    isAccessSequenceOperationInProgress = false;

                  //  UpdateInventoryButtons();
                }
                else
                {
                    //OutputText("Already inventory stopped...");
                }
            }
            catch
            {
                deviceIdWhichRunsInventory = selectedReader.ID;
                ActiveReaderStatus.IsInventoryRunning = true;

              //  UpdateInventoryButtons();
            }
        }

    }
}
