﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScannerData.Models
{
    public class TrolleyInventory
    {
		private string trolleyID;

		public string TrolleyID
		{
			get { return trolleyID; }
			set { trolleyID = value; }
		}

		private DateTime inTime;

		public DateTime InTime
        {
			get { return inTime; }
			set { inTime = value; }
		}


	}
}
