﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScannerData
{
    public class TagInfo
    {
        private int rowIndex = -1;
        private long tagSeenCount = 0;

        public TagInfo(TagData tg, int rowID, long tagSeenCnt)
        {
            Tag = tg;
            RowIndex = rowID;
            TagSeenTotalCount = tagSeenCnt;
        }
        public TagData Tag { get; set; }
        public int RowIndex { get { return rowIndex; } set { rowIndex = value; } }
        public long TagSeenTotalCount { get { return tagSeenCount; } set { tagSeenCount = value; } }
    }

}
