﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScannerData
{
    public class RFIDReaderItem
    {
        public RFIDReaderItem(RFIDReaderItemInfo deviceInfo)
        {
            Id = deviceInfo.HostAddress;
            Text = deviceInfo.FriendlyName;
            Value = deviceInfo.Reader;
            CommunicationMode = deviceInfo.CommunicationMode.ToString();
        }

        public string CommunicationMode { get; private set; }
        public string Text { get; private set; }
        public object Value { get; private set; }
        public string Id { get; private set; }
        public override string ToString()
        {
            return Text;
        }
    }
}
