﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Symbol.RFID.SDK.DemoApp.Entities;
using Symbol.RFID.SDK.Domain.Reader;

namespace Symbol.RFID.SDK.DemoApp
{
    public partial class WPAConfiguration : Form
    {
        #region Private Fields

        private frmMain mainForm = null;
        private BasicServiceSet selectedEntry = null;
        private List<WiFiScanInfo> scanInfoList = null;
        #endregion

        #region Properties

        public IRfidReader Reader { get; set; }

        #endregion

        #region Constructors
        public WPAConfiguration(frmMain mainForm)
        {
            InitializeComponent();
            this.mainForm = mainForm;
        }

        #endregion

        #region Form Event Handlers

        private void WAPConfiguration_Load(object sender, EventArgs e)
        {
            PopulateControls();
        }

        private void btnWiFiDisable_Click(object sender, EventArgs e)
        {
            RFIDLibraryUtility.WiFiEnableDisable(this.Reader, (txtWiFi.Text == "DISABLE"));
        }

        private void btnWiFiDisconnect_Click(object sender, EventArgs e)
        {
            RFIDLibraryUtility.DisconnectWiFi(this.Reader);
        }

        private void comboBoxEntries_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedEntry = comboBoxEntries.SelectedItem as BasicServiceSet;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txtSSID.Text) || string.IsNullOrEmpty(txtPassword.Text))
                {
                    MessageBox.Show("SSID and Password should not be empty.", "Error");
                    return;
                }
                RFIDLibraryUtility.AddBssEntry(this.Reader, txtSSID.Text, txtPassword.Text);
                mainForm.OutputText("WPA configuration: BSS : " + txtSSID.Text + " added.");
            }
            catch (Exception ex)
            {
                mainForm.OutputText(ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (chkAll.Checked)
                {
                    RFIDLibraryUtility.DeleteAllBssEntries(this.Reader);
                    mainForm.OutputText("WPA configuration : All BSS entries deleted.");
                }
                else
                {
                    if (string.IsNullOrEmpty(txtSSID.Text))
                    {
                        MessageBox.Show("Enter the specific BSS entry to delete.", "Error");
                        return;
                    }
                    RFIDLibraryUtility.DeleteBssEntry(this.Reader, txtSSID.Text.Trim());
                    mainForm.OutputText("WPA configuration : BSS : " + txtSSID.Text + " deleted.");
                }
            }
            catch (Exception ex)
            {
                mainForm.OutputText(ex.Message);
            }
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            try
            {
                if (chkSelectedEntry.Checked)
                {
                    RFIDLibraryUtility.ConnectWiFi(this.Reader, txtSSID.Text.Trim());
                    mainForm.OutputText("WIFI Connect to : "+ txtSSID.Text + " successful.");
                }
                else
                {
                    RFIDLibraryUtility.ConnectWiFi(this.Reader);
                    mainForm.OutputText("WIFI Connect successful.");
                }
            }
            catch (Exception ex)
            {
                mainForm.OutputText(ex.Message);
            }
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Retrieve WiFi, Configuration settings from the selected reader. 
        /// </summary>
        private void PopulateControls()
        {
            try
            {
                if (Reader != null)
                {
                    var wifistatus = RFIDLibraryUtility.GetWiFiStatus(this.Reader);
                    txtWiFi.Text = wifistatus.WiFi;
                    txtStatus.Text = wifistatus.Status;
                    txtMac.Text = wifistatus.MacAddress;
                    txtWiFiSsid.Text = wifistatus.SSID;

                    btnWiFiDisable.Text = (wifistatus.WiFi == "ENABLE") ? "Disable" : "Enable";
                    btnWiFiDisconnect.Enabled = (wifistatus.Status == "DISCONNECTED");

                    var bssEntries = RFIDLibraryUtility.GetBssEntries(this.Reader);
                    foreach (var item in bssEntries)
                    {
                        var entry = new BSSEntry(item);
                        comboBoxEntries.Items.Add(entry);
                    }
                }
            }
            catch (Exception ex)
            {
                mainForm.OutputText(ex.Message);
            }
        }

        #endregion

        private void btnScan_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            scanInfoList = RFIDLibraryUtility.Scan(this.Reader);
            grdWifi.DataSource = scanInfoList;
            grdWifi.Columns[2].Width = 160;
            Cursor.Current = Cursors.Default;
        }

        private void brnWiFiSave_Click(object sender, EventArgs e)
        {
            RFIDLibraryUtility.Save(this.Reader);
        }

        private void btnClearScan_Click(object sender, EventArgs e)
        {
            grdWifi.DataSource = null;
        }
    }
}
