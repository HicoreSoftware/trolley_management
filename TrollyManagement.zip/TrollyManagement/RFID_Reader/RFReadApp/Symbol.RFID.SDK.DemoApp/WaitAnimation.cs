﻿using System.Windows.Forms;

namespace Symbol.RFID.SDK.DemoApp
{
    public partial class WaitAnimation : Form
    {
        public WaitAnimation()
        {
            InitializeComponent();
            this.TransparencyKey = (BackColor);
        }
    }
}
