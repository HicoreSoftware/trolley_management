﻿using System;
using System.Windows.Forms;
using Symbol.RFID.SDK.Domain.Reader;

namespace Symbol.RFID.SDK.DemoApp
{
    public partial class NetworkConfiguration : Form
    {
        #region Private Fields

        private frmMain mainForm = null;

        #endregion

        #region Properties

        public IRfidReader Reader { get; set; }

        #endregion

        #region Constructors

        public NetworkConfiguration(frmMain mainForm)
        {
            InitializeComponent();
            this.mainForm = mainForm;
        }

        #endregion

        #region Form Event Handlers

        private void NetworkConfiguration_Load(object sender, EventArgs e)
        {
            GetNetworkConfiguration();
        }

        private void btnApply_Click(object sender, EventArgs e)
        {
            SetNetworkConfiguration();
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        #endregion

        #region Private Methods
        
        /// <summary>
        /// Retrieve network configuration settings from the selected reader. 
        /// </summary>
        private void GetNetworkConfiguration()
        {
            try
            {
                if (Reader != null)
                {
                    var configuration = RFIDLibraryUtility.GetNetworkConfiguration(this.Reader);
                    txtIpAddress.Text = configuration.IpAddress;
                    txtDns.Text = configuration.DNS;
                    txtMask.Text = configuration.NetMask;
                    txtGateway.Text = configuration.Gateway;
                    txtDhcp.Text = configuration.DHCP;
                }
            }
            catch (Exception ex)
            {
                mainForm.OutputText(ex.Message);
            }
        }

        /// <summary>
        /// Set network configuration settings to the reader. 
        /// </summary>
        private void SetNetworkConfiguration()
        {
            try
            {
                if (Reader != null)
                {
                    var configuration = Reader.Configurations.NetworkConfiguration;
                    configuration.IpAddress = txtIpAddress.Text.Trim();
                    configuration.DNS = txtDns.Text.Trim();
                    configuration.Gateway = txtGateway.Text.Trim();
                    configuration.NetMask = txtMask.Text.Trim();

                    RFIDLibraryUtility.SetNetworkConfiguration(this.Reader, configuration);

                    mainForm.OutputText("Network configuration successfully saved.");
                }
            }
            catch (Exception ex)
            {
                mainForm.OutputText(ex.Message);
            }
        }
        #endregion     
    }
}
