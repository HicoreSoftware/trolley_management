﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("RFID SDK Demonstration Application")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("d0d4e64d-ee52-487a-b6b2-df8c39f63c7e")]

[assembly: AssemblyCompany("Zebra Technologies")]
[assembly: AssemblyCopyright("©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.")]
[assembly: AssemblyDescription("Zebra RFID SDK Demo Application")]
[assembly: AssemblyProduct("RFID Demo Application")]

[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyTrademark("")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("3.0.32.0")]
