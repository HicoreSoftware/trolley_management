﻿using System.ComponentModel;
using System.Windows.Forms;

namespace Symbol.RFID.SDK.DemoApp
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TabControl tabContainer;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.tabInventory = new System.Windows.Forms.TabPage();
            this.grdTags = new System.Windows.Forms.DataGridView();
            this.btnExecuteOperationSequence = new System.Windows.Forms.Button();
            this.btnInventoryStart = new System.Windows.Forms.Button();
            this.btnPurgeTags = new System.Windows.Forms.Button();
            this.btnInventoryStop = new System.Windows.Forms.Button();
            this.tabTagLocate = new System.Windows.Forms.TabPage();
            this.label2 = new System.Windows.Forms.Label();
            this.txtTagId = new System.Windows.Forms.TextBox();
            this.lblTL = new System.Windows.Forms.Label();
            this.btnTagLocateStart = new System.Windows.Forms.Button();
            this.btnTagLocateStop = new System.Windows.Forms.Button();
            this.proximityPercentBar = new System.Windows.Forms.ProgressBar();
            this.tabReadWrite = new System.Windows.Forms.TabPage();
            this.btnWrite = new System.Windows.Forms.Button();
            this.btnRead = new System.Windows.Forms.Button();
            this.txtData = new System.Windows.Forms.TextBox();
            this.txtLength = new System.Windows.Forms.TextBox();
            this.txtOffset = new System.Windows.Forms.TextBox();
            this.cmbMemoryBank = new System.Windows.Forms.ComboBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtTagPattern = new System.Windows.Forms.TextBox();
            this.labelData = new System.Windows.Forms.Label();
            this.labelLength = new System.Windows.Forms.Label();
            this.labelOffset = new System.Windows.Forms.Label();
            this.labelMemBank = new System.Windows.Forms.Label();
            this.labelPassword = new System.Windows.Forms.Label();
            this.labelTagPattern = new System.Windows.Forms.Label();
            this.tabLock = new System.Windows.Forms.TabPage();
            this.btnLock = new System.Windows.Forms.Button();
            this.cmbLockPrivilege = new System.Windows.Forms.ComboBox();
            this.cmbMemoryBankLock = new System.Windows.Forms.ComboBox();
            this.txtPasswordLock = new System.Windows.Forms.TextBox();
            this.txtTagPatternLock = new System.Windows.Forms.TextBox();
            this.labelLockPrivilege = new System.Windows.Forms.Label();
            this.labelMemBankACLock = new System.Windows.Forms.Label();
            this.labelPasswordACLock = new System.Windows.Forms.Label();
            this.labelTagPatternACLock = new System.Windows.Forms.Label();
            this.tabKill = new System.Windows.Forms.TabPage();
            this.btnKill = new System.Windows.Forms.Button();
            this.txtPasswordKill = new System.Windows.Forms.TextBox();
            this.txtTagPatternKill = new System.Windows.Forms.TextBox();
            this.labelKillPassword = new System.Windows.Forms.Label();
            this.labelTagPatternKill = new System.Windows.Forms.Label();
            this.tabRSM = new System.Windows.Forms.TabPage();
            this.txtType = new System.Windows.Forms.TextBox();
            this.txtValue = new System.Windows.Forms.TextBox();
            this.txtAttribute = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btnSetAttribute = new System.Windows.Forms.Button();
            this.btnGetAttribute = new System.Windows.Forms.Button();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnClearSequenceOperation = new System.Windows.Forms.Button();
            this.cboOpLockPermission = new System.Windows.Forms.ComboBox();
            this.lblLockPrivilege = new System.Windows.Forms.Label();
            this.cboOpLockMemoryBank = new System.Windows.Forms.ComboBox();
            this.lblLockMemBank = new System.Windows.Forms.Label();
            this.btnEndSequenceOperation = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.btnBeginSequenceOperation = new System.Windows.Forms.Button();
            this.cboTagOperation = new System.Windows.Forms.ComboBox();
            this.btnAddSequenceOperation = new System.Windows.Forms.Button();
            this.txtOpMemBankData = new System.Windows.Forms.TextBox();
            this.txtOpLength = new System.Windows.Forms.TextBox();
            this.txtOpOffset = new System.Windows.Forms.TextBox();
            this.cboOpMemBank = new System.Windows.Forms.ComboBox();
            this.txtOpPwd = new System.Windows.Forms.TextBox();
            this.txtOpTagPattern = new System.Windows.Forms.TextBox();
            this.lblMemBankData = new System.Windows.Forms.Label();
            this.lblOpLength = new System.Windows.Forms.Label();
            this.lblOpOffset = new System.Windows.Forms.Label();
            this.lblOpMemBank = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.comboBoxReaders = new System.Windows.Forms.ComboBox();
            this.btnConnectDisconnect = new System.Windows.Forms.Button();
            this.lblReaders = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.settingsMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.antennaConfiguration = new System.Windows.Forms.ToolStripMenuItem();
            this.capabilitiesMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.regulatory = new System.Windows.Forms.ToolStripMenuItem();
            this.preFilters = new System.Windows.Forms.ToolStripMenuItem();
            this.singulationMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tagReportingMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.triggersMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.configurationMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.networkMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wpaConfigMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.versionMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveConfigMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnPairNew = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.lblTemperature = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblBatteryLevel = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblPower = new System.Windows.Forms.Label();
            this.btnManualConnect = new System.Windows.Forms.Button();
            this.lblLog = new System.Windows.Forms.Label();
            this.txtOutput = new System.Windows.Forms.TextBox();
            tabContainer = new System.Windows.Forms.TabControl();
            tabContainer.SuspendLayout();
            this.tabInventory.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdTags)).BeginInit();
            this.tabTagLocate.SuspendLayout();
            this.tabReadWrite.SuspendLayout();
            this.tabLock.SuspendLayout();
            this.tabKill.SuspendLayout();
            this.tabRSM.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabContainer
            // 
            tabContainer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            tabContainer.Controls.Add(this.tabInventory);
            tabContainer.Controls.Add(this.tabTagLocate);
            tabContainer.Controls.Add(this.tabReadWrite);
            tabContainer.Controls.Add(this.tabLock);
            tabContainer.Controls.Add(this.tabKill);
            tabContainer.Controls.Add(this.tabRSM);
            tabContainer.Controls.Add(this.tabPage1);
            tabContainer.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            tabContainer.Location = new System.Drawing.Point(23, 111);
            tabContainer.Margin = new System.Windows.Forms.Padding(4);
            tabContainer.Name = "tabContainer";
            tabContainer.SelectedIndex = 0;
            tabContainer.Size = new System.Drawing.Size(893, 298);
            tabContainer.TabIndex = 45;
            tabContainer.SelectedIndexChanged += new System.EventHandler(this.tabContainer_SelectedIndexChanged);
            // 
            // tabInventory
            // 
            this.tabInventory.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.tabInventory.Controls.Add(this.grdTags);
            this.tabInventory.Controls.Add(this.btnExecuteOperationSequence);
            this.tabInventory.Controls.Add(this.btnInventoryStart);
            this.tabInventory.Controls.Add(this.btnPurgeTags);
            this.tabInventory.Controls.Add(this.btnInventoryStop);
            this.tabInventory.Location = new System.Drawing.Point(4, 29);
            this.tabInventory.Margin = new System.Windows.Forms.Padding(4);
            this.tabInventory.Name = "tabInventory";
            this.tabInventory.Padding = new System.Windows.Forms.Padding(4);
            this.tabInventory.Size = new System.Drawing.Size(885, 265);
            this.tabInventory.TabIndex = 0;
            this.tabInventory.Text = "Inventory";
            // 
            // grdTags
            // 
            this.grdTags.AllowUserToAddRows = false;
            this.grdTags.AllowUserToDeleteRows = false;
            this.grdTags.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grdTags.BackgroundColor = System.Drawing.Color.White;
            this.grdTags.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdTags.Location = new System.Drawing.Point(11, 11);
            this.grdTags.Name = "grdTags";
            this.grdTags.RowHeadersWidth = 51;
            this.grdTags.RowTemplate.Height = 24;
            this.grdTags.Size = new System.Drawing.Size(686, 222);
            this.grdTags.TabIndex = 47;
            // 
            // btnExecuteOperationSequence
            // 
            this.btnExecuteOperationSequence.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExecuteOperationSequence.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnExecuteOperationSequence.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnExecuteOperationSequence.BackgroundImage")));
            this.btnExecuteOperationSequence.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnExecuteOperationSequence.FlatAppearance.BorderSize = 0;
            this.btnExecuteOperationSequence.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnExecuteOperationSequence.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExecuteOperationSequence.ForeColor = System.Drawing.Color.White;
            this.btnExecuteOperationSequence.Location = new System.Drawing.Point(704, 49);
            this.btnExecuteOperationSequence.Margin = new System.Windows.Forms.Padding(4);
            this.btnExecuteOperationSequence.Name = "btnExecuteOperationSequence";
            this.btnExecuteOperationSequence.Size = new System.Drawing.Size(172, 47);
            this.btnExecuteOperationSequence.TabIndex = 45;
            this.btnExecuteOperationSequence.Text = "START OPERATION SEQUENCE";
            this.btnExecuteOperationSequence.UseVisualStyleBackColor = false;
            this.btnExecuteOperationSequence.Click += new System.EventHandler(this.btnStartAccSeq_Click);
            // 
            // btnInventoryStart
            // 
            this.btnInventoryStart.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnInventoryStart.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnInventoryStart.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnInventoryStart.BackgroundImage")));
            this.btnInventoryStart.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnInventoryStart.FlatAppearance.BorderSize = 0;
            this.btnInventoryStart.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnInventoryStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInventoryStart.ForeColor = System.Drawing.Color.White;
            this.btnInventoryStart.Location = new System.Drawing.Point(704, 7);
            this.btnInventoryStart.Margin = new System.Windows.Forms.Padding(4);
            this.btnInventoryStart.Name = "btnInventoryStart";
            this.btnInventoryStart.Size = new System.Drawing.Size(172, 34);
            this.btnInventoryStart.TabIndex = 3;
            this.btnInventoryStart.Text = "START INVENTORY";
            this.btnInventoryStart.UseVisualStyleBackColor = false;
            this.btnInventoryStart.Click += new System.EventHandler(this.BtnInventoryStart_Click);
            // 
            // btnPurgeTags
            // 
            this.btnPurgeTags.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPurgeTags.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnPurgeTags.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPurgeTags.BackgroundImage")));
            this.btnPurgeTags.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnPurgeTags.FlatAppearance.BorderSize = 0;
            this.btnPurgeTags.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPurgeTags.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPurgeTags.ForeColor = System.Drawing.Color.White;
            this.btnPurgeTags.Location = new System.Drawing.Point(704, 104);
            this.btnPurgeTags.Margin = new System.Windows.Forms.Padding(4);
            this.btnPurgeTags.Name = "btnPurgeTags";
            this.btnPurgeTags.Size = new System.Drawing.Size(172, 34);
            this.btnPurgeTags.TabIndex = 44;
            this.btnPurgeTags.Text = "PURGE TAGS";
            this.btnPurgeTags.UseVisualStyleBackColor = false;
            this.btnPurgeTags.Click += new System.EventHandler(this.BtnPurgeTags_Click);
            // 
            // btnInventoryStop
            // 
            this.btnInventoryStop.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnInventoryStop.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnInventoryStop.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnInventoryStop.BackgroundImage")));
            this.btnInventoryStop.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnInventoryStop.FlatAppearance.BorderSize = 0;
            this.btnInventoryStop.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnInventoryStop.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInventoryStop.ForeColor = System.Drawing.Color.White;
            this.btnInventoryStop.Location = new System.Drawing.Point(705, 146);
            this.btnInventoryStop.Margin = new System.Windows.Forms.Padding(4);
            this.btnInventoryStop.Name = "btnInventoryStop";
            this.btnInventoryStop.Size = new System.Drawing.Size(172, 34);
            this.btnInventoryStop.TabIndex = 4;
            this.btnInventoryStop.Text = "STOP";
            this.btnInventoryStop.UseVisualStyleBackColor = false;
            this.btnInventoryStop.Click += new System.EventHandler(this.BtnInventoryStop_Click);
            // 
            // tabTagLocate
            // 
            this.tabTagLocate.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.tabTagLocate.Controls.Add(this.label2);
            this.tabTagLocate.Controls.Add(this.txtTagId);
            this.tabTagLocate.Controls.Add(this.lblTL);
            this.tabTagLocate.Controls.Add(this.btnTagLocateStart);
            this.tabTagLocate.Controls.Add(this.btnTagLocateStop);
            this.tabTagLocate.Controls.Add(this.proximityPercentBar);
            this.tabTagLocate.Location = new System.Drawing.Point(4, 29);
            this.tabTagLocate.Margin = new System.Windows.Forms.Padding(4);
            this.tabTagLocate.Name = "tabTagLocate";
            this.tabTagLocate.Padding = new System.Windows.Forms.Padding(4);
            this.tabTagLocate.Size = new System.Drawing.Size(885, 265);
            this.tabTagLocate.TabIndex = 1;
            this.tabTagLocate.Text = "Tag Locate";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 35);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 20);
            this.label2.TabIndex = 46;
            this.label2.Text = "Tag Id";
            // 
            // txtTagId
            // 
            this.txtTagId.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtTagId.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtTagId.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtTagId.Location = new System.Drawing.Point(143, 32);
            this.txtTagId.Margin = new System.Windows.Forms.Padding(4);
            this.txtTagId.Name = "txtTagId";
            this.txtTagId.Size = new System.Drawing.Size(720, 27);
            this.txtTagId.TabIndex = 5;
            this.txtTagId.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.HexInput_KeyPress);
            // 
            // lblTL
            // 
            this.lblTL.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.lblTL.AutoSize = true;
            this.lblTL.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTL.Location = new System.Drawing.Point(433, 110);
            this.lblTL.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTL.Name = "lblTL";
            this.lblTL.Size = new System.Drawing.Size(29, 31);
            this.lblTL.TabIndex = 4;
            this.lblTL.Text = "0";
            this.lblTL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnTagLocateStart
            // 
            this.btnTagLocateStart.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnTagLocateStart.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnTagLocateStart.BackgroundImage")));
            this.btnTagLocateStart.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnTagLocateStart.FlatAppearance.BorderSize = 0;
            this.btnTagLocateStart.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnTagLocateStart.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnTagLocateStart.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnTagLocateStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTagLocateStart.ForeColor = System.Drawing.Color.White;
            this.btnTagLocateStart.Location = new System.Drawing.Point(528, 174);
            this.btnTagLocateStart.Margin = new System.Windows.Forms.Padding(4);
            this.btnTagLocateStart.Name = "btnTagLocateStart";
            this.btnTagLocateStart.Size = new System.Drawing.Size(164, 34);
            this.btnTagLocateStart.TabIndex = 3;
            this.btnTagLocateStart.Text = "START";
            this.btnTagLocateStart.UseVisualStyleBackColor = false;
            this.btnTagLocateStart.Click += new System.EventHandler(this.BtnTagLocateStart_Click);
            // 
            // btnTagLocateStop
            // 
            this.btnTagLocateStop.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnTagLocateStop.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnTagLocateStop.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnTagLocateStop.BackgroundImage")));
            this.btnTagLocateStop.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnTagLocateStop.FlatAppearance.BorderSize = 0;
            this.btnTagLocateStop.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnTagLocateStop.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnTagLocateStop.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnTagLocateStop.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTagLocateStop.ForeColor = System.Drawing.Color.White;
            this.btnTagLocateStop.Location = new System.Drawing.Point(700, 174);
            this.btnTagLocateStop.Margin = new System.Windows.Forms.Padding(4);
            this.btnTagLocateStop.Name = "btnTagLocateStop";
            this.btnTagLocateStop.Size = new System.Drawing.Size(164, 34);
            this.btnTagLocateStop.TabIndex = 2;
            this.btnTagLocateStop.Text = "STOP";
            this.btnTagLocateStop.UseVisualStyleBackColor = false;
            this.btnTagLocateStop.Click += new System.EventHandler(this.BtnTagLocateStop_Click);
            // 
            // proximityPercentBar
            // 
            this.proximityPercentBar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.proximityPercentBar.Location = new System.Drawing.Point(21, 71);
            this.proximityPercentBar.Margin = new System.Windows.Forms.Padding(4);
            this.proximityPercentBar.Name = "proximityPercentBar";
            this.proximityPercentBar.Size = new System.Drawing.Size(842, 28);
            this.proximityPercentBar.TabIndex = 0;
            // 
            // tabReadWrite
            // 
            this.tabReadWrite.Controls.Add(this.btnWrite);
            this.tabReadWrite.Controls.Add(this.btnRead);
            this.tabReadWrite.Controls.Add(this.txtData);
            this.tabReadWrite.Controls.Add(this.txtLength);
            this.tabReadWrite.Controls.Add(this.txtOffset);
            this.tabReadWrite.Controls.Add(this.cmbMemoryBank);
            this.tabReadWrite.Controls.Add(this.txtPassword);
            this.tabReadWrite.Controls.Add(this.txtTagPattern);
            this.tabReadWrite.Controls.Add(this.labelData);
            this.tabReadWrite.Controls.Add(this.labelLength);
            this.tabReadWrite.Controls.Add(this.labelOffset);
            this.tabReadWrite.Controls.Add(this.labelMemBank);
            this.tabReadWrite.Controls.Add(this.labelPassword);
            this.tabReadWrite.Controls.Add(this.labelTagPattern);
            this.tabReadWrite.Location = new System.Drawing.Point(4, 29);
            this.tabReadWrite.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabReadWrite.Name = "tabReadWrite";
            this.tabReadWrite.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabReadWrite.Size = new System.Drawing.Size(885, 265);
            this.tabReadWrite.TabIndex = 2;
            this.tabReadWrite.Text = "Read / Write";
            this.tabReadWrite.UseVisualStyleBackColor = true;
            // 
            // btnWrite
            // 
            this.btnWrite.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnWrite.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnWrite.BackgroundImage")));
            this.btnWrite.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnWrite.FlatAppearance.BorderSize = 0;
            this.btnWrite.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnWrite.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnWrite.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnWrite.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWrite.ForeColor = System.Drawing.Color.White;
            this.btnWrite.Location = new System.Drawing.Point(699, 172);
            this.btnWrite.Margin = new System.Windows.Forms.Padding(4);
            this.btnWrite.Name = "btnWrite";
            this.btnWrite.Size = new System.Drawing.Size(164, 34);
            this.btnWrite.TabIndex = 29;
            this.btnWrite.Text = "WRITE";
            this.btnWrite.UseVisualStyleBackColor = false;
            this.btnWrite.Click += new System.EventHandler(this.btnWrite_Click);
            // 
            // btnRead
            // 
            this.btnRead.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnRead.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnRead.BackgroundImage")));
            this.btnRead.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnRead.FlatAppearance.BorderSize = 0;
            this.btnRead.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnRead.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnRead.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRead.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRead.ForeColor = System.Drawing.Color.White;
            this.btnRead.Location = new System.Drawing.Point(699, 130);
            this.btnRead.Margin = new System.Windows.Forms.Padding(4);
            this.btnRead.Name = "btnRead";
            this.btnRead.Size = new System.Drawing.Size(164, 34);
            this.btnRead.TabIndex = 28;
            this.btnRead.Text = "READ";
            this.btnRead.UseVisualStyleBackColor = false;
            this.btnRead.Click += new System.EventHandler(this.btnRead_Click);
            // 
            // txtData
            // 
            this.txtData.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtData.Location = new System.Drawing.Point(528, 32);
            this.txtData.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(335, 27);
            this.txtData.TabIndex = 27;
            // 
            // txtLength
            // 
            this.txtLength.Location = new System.Drawing.Point(143, 103);
            this.txtLength.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtLength.Name = "txtLength";
            this.txtLength.Size = new System.Drawing.Size(265, 27);
            this.txtLength.TabIndex = 26;
            this.txtLength.Text = "0";
            // 
            // txtOffset
            // 
            this.txtOffset.Location = new System.Drawing.Point(143, 67);
            this.txtOffset.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtOffset.Name = "txtOffset";
            this.txtOffset.Size = new System.Drawing.Size(265, 27);
            this.txtOffset.TabIndex = 25;
            this.txtOffset.Text = "2";
            // 
            // cmbMemoryBank
            // 
            this.cmbMemoryBank.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMemoryBank.FormattingEnabled = true;
            this.cmbMemoryBank.Location = new System.Drawing.Point(143, 174);
            this.cmbMemoryBank.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbMemoryBank.Name = "cmbMemoryBank";
            this.cmbMemoryBank.Size = new System.Drawing.Size(265, 28);
            this.cmbMemoryBank.TabIndex = 24;
            // 
            // txtPassword
            // 
            this.txtPassword.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPassword.Location = new System.Drawing.Point(143, 136);
            this.txtPassword.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(265, 27);
            this.txtPassword.TabIndex = 23;
            this.txtPassword.Text = "00";
            // 
            // txtTagPattern
            // 
            this.txtTagPattern.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtTagPattern.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtTagPattern.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtTagPattern.Location = new System.Drawing.Point(143, 32);
            this.txtTagPattern.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTagPattern.Name = "txtTagPattern";
            this.txtTagPattern.Size = new System.Drawing.Size(265, 27);
            this.txtTagPattern.TabIndex = 22;
            // 
            // labelData
            // 
            this.labelData.AutoSize = true;
            this.labelData.Location = new System.Drawing.Point(469, 35);
            this.labelData.Name = "labelData";
            this.labelData.Size = new System.Drawing.Size(41, 20);
            this.labelData.TabIndex = 21;
            this.labelData.Text = "Data";
            // 
            // labelLength
            // 
            this.labelLength.AutoSize = true;
            this.labelLength.Location = new System.Drawing.Point(21, 107);
            this.labelLength.Name = "labelLength";
            this.labelLength.Size = new System.Drawing.Size(108, 20);
            this.labelLength.TabIndex = 20;
            this.labelLength.Text = "Length (words)";
            // 
            // labelOffset
            // 
            this.labelOffset.AutoSize = true;
            this.labelOffset.Location = new System.Drawing.Point(21, 71);
            this.labelOffset.Name = "labelOffset";
            this.labelOffset.Size = new System.Drawing.Size(103, 20);
            this.labelOffset.TabIndex = 19;
            this.labelOffset.Text = "Offset (words)";
            // 
            // labelMemBank
            // 
            this.labelMemBank.AutoSize = true;
            this.labelMemBank.Location = new System.Drawing.Point(23, 178);
            this.labelMemBank.Name = "labelMemBank";
            this.labelMemBank.Size = new System.Drawing.Size(100, 20);
            this.labelMemBank.TabIndex = 18;
            this.labelMemBank.Text = "Memory Bank";
            // 
            // labelPassword
            // 
            this.labelPassword.AutoSize = true;
            this.labelPassword.Location = new System.Drawing.Point(23, 142);
            this.labelPassword.Name = "labelPassword";
            this.labelPassword.Size = new System.Drawing.Size(70, 20);
            this.labelPassword.TabIndex = 17;
            this.labelPassword.Text = "Password";
            // 
            // labelTagPattern
            // 
            this.labelTagPattern.AutoSize = true;
            this.labelTagPattern.Location = new System.Drawing.Point(21, 35);
            this.labelTagPattern.Name = "labelTagPattern";
            this.labelTagPattern.Size = new System.Drawing.Size(82, 20);
            this.labelTagPattern.TabIndex = 16;
            this.labelTagPattern.Text = "Tag Pattern";
            // 
            // tabLock
            // 
            this.tabLock.Controls.Add(this.btnLock);
            this.tabLock.Controls.Add(this.cmbLockPrivilege);
            this.tabLock.Controls.Add(this.cmbMemoryBankLock);
            this.tabLock.Controls.Add(this.txtPasswordLock);
            this.tabLock.Controls.Add(this.txtTagPatternLock);
            this.tabLock.Controls.Add(this.labelLockPrivilege);
            this.tabLock.Controls.Add(this.labelMemBankACLock);
            this.tabLock.Controls.Add(this.labelPasswordACLock);
            this.tabLock.Controls.Add(this.labelTagPatternACLock);
            this.tabLock.Location = new System.Drawing.Point(4, 29);
            this.tabLock.Name = "tabLock";
            this.tabLock.Padding = new System.Windows.Forms.Padding(3);
            this.tabLock.Size = new System.Drawing.Size(885, 265);
            this.tabLock.TabIndex = 3;
            this.tabLock.Text = "Lock";
            this.tabLock.UseVisualStyleBackColor = true;
            // 
            // btnLock
            // 
            this.btnLock.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnLock.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnLock.BackgroundImage")));
            this.btnLock.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnLock.FlatAppearance.BorderSize = 0;
            this.btnLock.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnLock.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnLock.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLock.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLock.ForeColor = System.Drawing.Color.White;
            this.btnLock.Location = new System.Drawing.Point(700, 201);
            this.btnLock.Margin = new System.Windows.Forms.Padding(4);
            this.btnLock.Name = "btnLock";
            this.btnLock.Size = new System.Drawing.Size(164, 34);
            this.btnLock.TabIndex = 25;
            this.btnLock.Text = "LOCK";
            this.btnLock.UseVisualStyleBackColor = false;
            this.btnLock.Click += new System.EventHandler(this.btnLock_Click);
            // 
            // cmbLockPrivilege
            // 
            this.cmbLockPrivilege.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLockPrivilege.FormattingEnabled = true;
            this.cmbLockPrivilege.Location = new System.Drawing.Point(143, 136);
            this.cmbLockPrivilege.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbLockPrivilege.Name = "cmbLockPrivilege";
            this.cmbLockPrivilege.Size = new System.Drawing.Size(265, 28);
            this.cmbLockPrivilege.TabIndex = 24;
            // 
            // cmbMemoryBankLock
            // 
            this.cmbMemoryBankLock.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMemoryBankLock.FormattingEnabled = true;
            this.cmbMemoryBankLock.Location = new System.Drawing.Point(143, 103);
            this.cmbMemoryBankLock.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbMemoryBankLock.Name = "cmbMemoryBankLock";
            this.cmbMemoryBankLock.Size = new System.Drawing.Size(265, 28);
            this.cmbMemoryBankLock.TabIndex = 23;
            // 
            // txtPasswordLock
            // 
            this.txtPasswordLock.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPasswordLock.Location = new System.Drawing.Point(143, 67);
            this.txtPasswordLock.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtPasswordLock.Name = "txtPasswordLock";
            this.txtPasswordLock.Size = new System.Drawing.Size(265, 27);
            this.txtPasswordLock.TabIndex = 22;
            this.txtPasswordLock.Text = "00";
            // 
            // txtTagPatternLock
            // 
            this.txtTagPatternLock.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtTagPatternLock.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtTagPatternLock.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtTagPatternLock.Location = new System.Drawing.Point(143, 32);
            this.txtTagPatternLock.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTagPatternLock.Name = "txtTagPatternLock";
            this.txtTagPatternLock.Size = new System.Drawing.Size(265, 27);
            this.txtTagPatternLock.TabIndex = 21;
            // 
            // labelLockPrivilege
            // 
            this.labelLockPrivilege.AutoSize = true;
            this.labelLockPrivilege.Location = new System.Drawing.Point(23, 142);
            this.labelLockPrivilege.Name = "labelLockPrivilege";
            this.labelLockPrivilege.Size = new System.Drawing.Size(100, 20);
            this.labelLockPrivilege.TabIndex = 20;
            this.labelLockPrivilege.Text = "Lock Privilege";
            // 
            // labelMemBankACLock
            // 
            this.labelMemBankACLock.AutoSize = true;
            this.labelMemBankACLock.Location = new System.Drawing.Point(21, 107);
            this.labelMemBankACLock.Name = "labelMemBankACLock";
            this.labelMemBankACLock.Size = new System.Drawing.Size(100, 20);
            this.labelMemBankACLock.TabIndex = 19;
            this.labelMemBankACLock.Text = "Memory Bank";
            // 
            // labelPasswordACLock
            // 
            this.labelPasswordACLock.AutoSize = true;
            this.labelPasswordACLock.Location = new System.Drawing.Point(21, 71);
            this.labelPasswordACLock.Name = "labelPasswordACLock";
            this.labelPasswordACLock.Size = new System.Drawing.Size(70, 20);
            this.labelPasswordACLock.TabIndex = 18;
            this.labelPasswordACLock.Text = "Password";
            // 
            // labelTagPatternACLock
            // 
            this.labelTagPatternACLock.AutoSize = true;
            this.labelTagPatternACLock.Location = new System.Drawing.Point(21, 35);
            this.labelTagPatternACLock.Name = "labelTagPatternACLock";
            this.labelTagPatternACLock.Size = new System.Drawing.Size(82, 20);
            this.labelTagPatternACLock.TabIndex = 17;
            this.labelTagPatternACLock.Text = "Tag Pattern";
            // 
            // tabKill
            // 
            this.tabKill.Controls.Add(this.btnKill);
            this.tabKill.Controls.Add(this.txtPasswordKill);
            this.tabKill.Controls.Add(this.txtTagPatternKill);
            this.tabKill.Controls.Add(this.labelKillPassword);
            this.tabKill.Controls.Add(this.labelTagPatternKill);
            this.tabKill.Location = new System.Drawing.Point(4, 29);
            this.tabKill.Name = "tabKill";
            this.tabKill.Padding = new System.Windows.Forms.Padding(3);
            this.tabKill.Size = new System.Drawing.Size(885, 265);
            this.tabKill.TabIndex = 4;
            this.tabKill.Text = "Kill";
            this.tabKill.UseVisualStyleBackColor = true;
            // 
            // btnKill
            // 
            this.btnKill.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnKill.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnKill.BackgroundImage")));
            this.btnKill.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnKill.FlatAppearance.BorderSize = 0;
            this.btnKill.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnKill.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnKill.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnKill.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKill.ForeColor = System.Drawing.Color.White;
            this.btnKill.Location = new System.Drawing.Point(700, 174);
            this.btnKill.Margin = new System.Windows.Forms.Padding(4);
            this.btnKill.Name = "btnKill";
            this.btnKill.Size = new System.Drawing.Size(164, 34);
            this.btnKill.TabIndex = 22;
            this.btnKill.Text = "KILL";
            this.btnKill.UseVisualStyleBackColor = false;
            this.btnKill.Click += new System.EventHandler(this.btnKill_Click);
            // 
            // txtPasswordKill
            // 
            this.txtPasswordKill.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPasswordKill.Location = new System.Drawing.Point(143, 67);
            this.txtPasswordKill.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtPasswordKill.Name = "txtPasswordKill";
            this.txtPasswordKill.Size = new System.Drawing.Size(265, 27);
            this.txtPasswordKill.TabIndex = 21;
            this.txtPasswordKill.Text = "00";
            // 
            // txtTagPatternKill
            // 
            this.txtTagPatternKill.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtTagPatternKill.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtTagPatternKill.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtTagPatternKill.Location = new System.Drawing.Point(143, 32);
            this.txtTagPatternKill.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTagPatternKill.Name = "txtTagPatternKill";
            this.txtTagPatternKill.Size = new System.Drawing.Size(265, 27);
            this.txtTagPatternKill.TabIndex = 20;
            // 
            // labelKillPassword
            // 
            this.labelKillPassword.AutoSize = true;
            this.labelKillPassword.Location = new System.Drawing.Point(21, 71);
            this.labelKillPassword.Name = "labelKillPassword";
            this.labelKillPassword.Size = new System.Drawing.Size(95, 20);
            this.labelKillPassword.TabIndex = 19;
            this.labelKillPassword.Text = "Kill Password";
            // 
            // labelTagPatternKill
            // 
            this.labelTagPatternKill.AutoSize = true;
            this.labelTagPatternKill.Location = new System.Drawing.Point(21, 35);
            this.labelTagPatternKill.Name = "labelTagPatternKill";
            this.labelTagPatternKill.Size = new System.Drawing.Size(82, 20);
            this.labelTagPatternKill.TabIndex = 18;
            this.labelTagPatternKill.Text = "Tag Pattern";
            // 
            // tabRSM
            // 
            this.tabRSM.Controls.Add(this.txtType);
            this.tabRSM.Controls.Add(this.txtValue);
            this.tabRSM.Controls.Add(this.txtAttribute);
            this.tabRSM.Controls.Add(this.label4);
            this.tabRSM.Controls.Add(this.label7);
            this.tabRSM.Controls.Add(this.label8);
            this.tabRSM.Controls.Add(this.btnSetAttribute);
            this.tabRSM.Controls.Add(this.btnGetAttribute);
            this.tabRSM.Location = new System.Drawing.Point(4, 29);
            this.tabRSM.Name = "tabRSM";
            this.tabRSM.Padding = new System.Windows.Forms.Padding(3);
            this.tabRSM.Size = new System.Drawing.Size(885, 265);
            this.tabRSM.TabIndex = 5;
            this.tabRSM.Text = "RSM";
            this.tabRSM.UseVisualStyleBackColor = true;
            // 
            // txtType
            // 
            this.txtType.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtType.Location = new System.Drawing.Point(528, 32);
            this.txtType.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtType.Name = "txtType";
            this.txtType.Size = new System.Drawing.Size(335, 27);
            this.txtType.TabIndex = 37;
            // 
            // txtValue
            // 
            this.txtValue.AcceptsReturn = true;
            this.txtValue.Location = new System.Drawing.Point(143, 67);
            this.txtValue.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtValue.Multiline = true;
            this.txtValue.Name = "txtValue";
            this.txtValue.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtValue.Size = new System.Drawing.Size(720, 90);
            this.txtValue.TabIndex = 36;
            // 
            // txtAttribute
            // 
            this.txtAttribute.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtAttribute.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtAttribute.Location = new System.Drawing.Point(143, 32);
            this.txtAttribute.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtAttribute.Name = "txtAttribute";
            this.txtAttribute.Size = new System.Drawing.Size(265, 27);
            this.txtAttribute.TabIndex = 35;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(21, 71);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 20);
            this.label4.TabIndex = 34;
            this.label4.Text = "Value";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(469, 35);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(40, 20);
            this.label7.TabIndex = 33;
            this.label7.Text = "Type";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(21, 35);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(68, 20);
            this.label8.TabIndex = 32;
            this.label8.Text = "Attribute";
            // 
            // btnSetAttribute
            // 
            this.btnSetAttribute.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSetAttribute.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSetAttribute.BackgroundImage")));
            this.btnSetAttribute.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnSetAttribute.FlatAppearance.BorderSize = 0;
            this.btnSetAttribute.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnSetAttribute.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnSetAttribute.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSetAttribute.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSetAttribute.ForeColor = System.Drawing.Color.White;
            this.btnSetAttribute.Location = new System.Drawing.Point(700, 174);
            this.btnSetAttribute.Margin = new System.Windows.Forms.Padding(4);
            this.btnSetAttribute.Name = "btnSetAttribute";
            this.btnSetAttribute.Size = new System.Drawing.Size(164, 34);
            this.btnSetAttribute.TabIndex = 31;
            this.btnSetAttribute.Text = "SET";
            this.btnSetAttribute.UseVisualStyleBackColor = false;
            this.btnSetAttribute.Click += new System.EventHandler(this.btnSetAttribute_Click);
            // 
            // btnGetAttribute
            // 
            this.btnGetAttribute.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnGetAttribute.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnGetAttribute.BackgroundImage")));
            this.btnGetAttribute.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnGetAttribute.FlatAppearance.BorderSize = 0;
            this.btnGetAttribute.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnGetAttribute.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnGetAttribute.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGetAttribute.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGetAttribute.ForeColor = System.Drawing.Color.White;
            this.btnGetAttribute.Location = new System.Drawing.Point(528, 174);
            this.btnGetAttribute.Margin = new System.Windows.Forms.Padding(4);
            this.btnGetAttribute.Name = "btnGetAttribute";
            this.btnGetAttribute.Size = new System.Drawing.Size(164, 34);
            this.btnGetAttribute.TabIndex = 30;
            this.btnGetAttribute.Text = "GET";
            this.btnGetAttribute.UseVisualStyleBackColor = false;
            this.btnGetAttribute.Click += new System.EventHandler(this.btnGetAttribute_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnClearSequenceOperation);
            this.tabPage1.Controls.Add(this.cboOpLockPermission);
            this.tabPage1.Controls.Add(this.lblLockPrivilege);
            this.tabPage1.Controls.Add(this.cboOpLockMemoryBank);
            this.tabPage1.Controls.Add(this.lblLockMemBank);
            this.tabPage1.Controls.Add(this.btnEndSequenceOperation);
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Controls.Add(this.btnBeginSequenceOperation);
            this.tabPage1.Controls.Add(this.cboTagOperation);
            this.tabPage1.Controls.Add(this.btnAddSequenceOperation);
            this.tabPage1.Controls.Add(this.txtOpMemBankData);
            this.tabPage1.Controls.Add(this.txtOpLength);
            this.tabPage1.Controls.Add(this.txtOpOffset);
            this.tabPage1.Controls.Add(this.cboOpMemBank);
            this.tabPage1.Controls.Add(this.txtOpPwd);
            this.tabPage1.Controls.Add(this.txtOpTagPattern);
            this.tabPage1.Controls.Add(this.lblMemBankData);
            this.tabPage1.Controls.Add(this.lblOpLength);
            this.tabPage1.Controls.Add(this.lblOpOffset);
            this.tabPage1.Controls.Add(this.lblOpMemBank);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(885, 265);
            this.tabPage1.TabIndex = 6;
            this.tabPage1.Text = "Access Operation Sequence";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnClearSequenceOperation
            // 
            this.btnClearSequenceOperation.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClearSequenceOperation.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnClearSequenceOperation.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnClearSequenceOperation.BackgroundImage")));
            this.btnClearSequenceOperation.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnClearSequenceOperation.FlatAppearance.BorderSize = 0;
            this.btnClearSequenceOperation.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnClearSequenceOperation.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnClearSequenceOperation.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnClearSequenceOperation.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearSequenceOperation.ForeColor = System.Drawing.Color.White;
            this.btnClearSequenceOperation.Location = new System.Drawing.Point(603, 147);
            this.btnClearSequenceOperation.Margin = new System.Windows.Forms.Padding(4);
            this.btnClearSequenceOperation.Name = "btnClearSequenceOperation";
            this.btnClearSequenceOperation.Size = new System.Drawing.Size(251, 34);
            this.btnClearSequenceOperation.TabIndex = 58;
            this.btnClearSequenceOperation.Text = "Clear Operation Sequence";
            this.btnClearSequenceOperation.UseVisualStyleBackColor = false;
            this.btnClearSequenceOperation.Click += new System.EventHandler(this.btnClearOpSeq_Click);
            // 
            // cboOpLockPermission
            // 
            this.cboOpLockPermission.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cboOpLockPermission.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboOpLockPermission.FormattingEnabled = true;
            this.cboOpLockPermission.Items.AddRange(new object[] {
            "UNLOCK",
            "PERMANENT_UNLOCK",
            "READ_WRITE",
            "PERMANENT_LOCK"});
            this.cboOpLockPermission.Location = new System.Drawing.Point(603, 193);
            this.cboOpLockPermission.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cboOpLockPermission.Name = "cboOpLockPermission";
            this.cboOpLockPermission.Size = new System.Drawing.Size(251, 28);
            this.cboOpLockPermission.TabIndex = 57;
            // 
            // lblLockPrivilege
            // 
            this.lblLockPrivilege.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblLockPrivilege.AutoSize = true;
            this.lblLockPrivilege.Location = new System.Drawing.Point(494, 197);
            this.lblLockPrivilege.Name = "lblLockPrivilege";
            this.lblLockPrivilege.Size = new System.Drawing.Size(100, 20);
            this.lblLockPrivilege.TabIndex = 56;
            this.lblLockPrivilege.Text = "Lock Privilege";
            // 
            // cboOpLockMemoryBank
            // 
            this.cboOpLockMemoryBank.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboOpLockMemoryBank.FormattingEnabled = true;
            this.cboOpLockMemoryBank.Items.AddRange(new object[] {
            "EPC",
            "ACCESS_PASSWORD",
            "KILL_PASSWORD",
            " TID",
            "USER"});
            this.cboOpLockMemoryBank.Location = new System.Drawing.Point(172, 196);
            this.cboOpLockMemoryBank.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cboOpLockMemoryBank.Name = "cboOpLockMemoryBank";
            this.cboOpLockMemoryBank.Size = new System.Drawing.Size(255, 28);
            this.cboOpLockMemoryBank.TabIndex = 55;
            // 
            // lblLockMemBank
            // 
            this.lblLockMemBank.AutoSize = true;
            this.lblLockMemBank.Location = new System.Drawing.Point(18, 198);
            this.lblLockMemBank.Name = "lblLockMemBank";
            this.lblLockMemBank.Size = new System.Drawing.Size(134, 20);
            this.lblLockMemBank.TabIndex = 54;
            this.lblLockMemBank.Text = "Lock Memory Bank";
            // 
            // btnEndSequenceOperation
            // 
            this.btnEndSequenceOperation.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnEndSequenceOperation.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnEndSequenceOperation.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnEndSequenceOperation.BackgroundImage")));
            this.btnEndSequenceOperation.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnEndSequenceOperation.FlatAppearance.BorderSize = 0;
            this.btnEndSequenceOperation.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnEndSequenceOperation.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnEndSequenceOperation.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEndSequenceOperation.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEndSequenceOperation.ForeColor = System.Drawing.Color.White;
            this.btnEndSequenceOperation.Location = new System.Drawing.Point(603, 105);
            this.btnEndSequenceOperation.Margin = new System.Windows.Forms.Padding(4);
            this.btnEndSequenceOperation.Name = "btnEndSequenceOperation";
            this.btnEndSequenceOperation.Size = new System.Drawing.Size(251, 34);
            this.btnEndSequenceOperation.TabIndex = 53;
            this.btnEndSequenceOperation.Text = "End Operation Sequence";
            this.btnEndSequenceOperation.UseVisualStyleBackColor = false;
            this.btnEndSequenceOperation.Click += new System.EventHandler(this.btnEndSeqOp_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(18, 25);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(76, 20);
            this.label14.TabIndex = 45;
            this.label14.Text = "Operation";
            // 
            // btnBeginSequenceOperation
            // 
            this.btnBeginSequenceOperation.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBeginSequenceOperation.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnBeginSequenceOperation.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBeginSequenceOperation.BackgroundImage")));
            this.btnBeginSequenceOperation.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnBeginSequenceOperation.FlatAppearance.BorderSize = 0;
            this.btnBeginSequenceOperation.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnBeginSequenceOperation.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnBeginSequenceOperation.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBeginSequenceOperation.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBeginSequenceOperation.ForeColor = System.Drawing.Color.White;
            this.btnBeginSequenceOperation.Location = new System.Drawing.Point(603, 21);
            this.btnBeginSequenceOperation.Margin = new System.Windows.Forms.Padding(4);
            this.btnBeginSequenceOperation.Name = "btnBeginSequenceOperation";
            this.btnBeginSequenceOperation.Size = new System.Drawing.Size(251, 34);
            this.btnBeginSequenceOperation.TabIndex = 46;
            this.btnBeginSequenceOperation.Text = "Begin Operation Sequence";
            this.btnBeginSequenceOperation.UseVisualStyleBackColor = false;
            this.btnBeginSequenceOperation.Click += new System.EventHandler(this.btnBeginSeqOp_Click);
            // 
            // cboTagOperation
            // 
            this.cboTagOperation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTagOperation.FormattingEnabled = true;
            this.cboTagOperation.Items.AddRange(new object[] {
            "READ",
            "WRITE",
            "LOCK"});
            this.cboTagOperation.Location = new System.Drawing.Point(172, 21);
            this.cboTagOperation.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cboTagOperation.Name = "cboTagOperation";
            this.cboTagOperation.Size = new System.Drawing.Size(254, 28);
            this.cboTagOperation.TabIndex = 44;
            this.cboTagOperation.SelectedIndexChanged += new System.EventHandler(this.cboTagOperation_SelectedIndexChanged);
            // 
            // btnAddSequenceOperation
            // 
            this.btnAddSequenceOperation.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddSequenceOperation.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnAddSequenceOperation.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAddSequenceOperation.BackgroundImage")));
            this.btnAddSequenceOperation.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnAddSequenceOperation.FlatAppearance.BorderSize = 0;
            this.btnAddSequenceOperation.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnAddSequenceOperation.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnAddSequenceOperation.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAddSequenceOperation.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddSequenceOperation.ForeColor = System.Drawing.Color.White;
            this.btnAddSequenceOperation.Location = new System.Drawing.Point(603, 63);
            this.btnAddSequenceOperation.Margin = new System.Windows.Forms.Padding(4);
            this.btnAddSequenceOperation.Name = "btnAddSequenceOperation";
            this.btnAddSequenceOperation.Size = new System.Drawing.Size(251, 34);
            this.btnAddSequenceOperation.TabIndex = 43;
            this.btnAddSequenceOperation.Text = "Add to Operation Sequence >>";
            this.btnAddSequenceOperation.UseVisualStyleBackColor = false;
            this.btnAddSequenceOperation.Click += new System.EventHandler(this.btnAddSeqOp_Click);
            // 
            // txtOpMemBankData
            // 
            this.txtOpMemBankData.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtOpMemBankData.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtOpMemBankData.Location = new System.Drawing.Point(172, 229);
            this.txtOpMemBankData.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtOpMemBankData.Multiline = true;
            this.txtOpMemBankData.Name = "txtOpMemBankData";
            this.txtOpMemBankData.Size = new System.Drawing.Size(682, 27);
            this.txtOpMemBankData.TabIndex = 41;
            // 
            // txtOpLength
            // 
            this.txtOpLength.Location = new System.Drawing.Point(363, 126);
            this.txtOpLength.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtOpLength.Name = "txtOpLength";
            this.txtOpLength.Size = new System.Drawing.Size(64, 27);
            this.txtOpLength.TabIndex = 40;
            this.txtOpLength.Text = "0";
            // 
            // txtOpOffset
            // 
            this.txtOpOffset.Location = new System.Drawing.Point(172, 126);
            this.txtOpOffset.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtOpOffset.Name = "txtOpOffset";
            this.txtOpOffset.Size = new System.Drawing.Size(56, 27);
            this.txtOpOffset.TabIndex = 39;
            this.txtOpOffset.Text = "2";
            // 
            // cboOpMemBank
            // 
            this.cboOpMemBank.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboOpMemBank.FormattingEnabled = true;
            this.cboOpMemBank.Items.AddRange(new object[] {
            "EPC",
            "TID",
            "USER",
            " RESV"});
            this.cboOpMemBank.Location = new System.Drawing.Point(172, 162);
            this.cboOpMemBank.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cboOpMemBank.Name = "cboOpMemBank";
            this.cboOpMemBank.Size = new System.Drawing.Size(255, 28);
            this.cboOpMemBank.TabIndex = 38;
            // 
            // txtOpPwd
            // 
            this.txtOpPwd.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtOpPwd.Location = new System.Drawing.Point(172, 92);
            this.txtOpPwd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtOpPwd.Name = "txtOpPwd";
            this.txtOpPwd.Size = new System.Drawing.Size(254, 27);
            this.txtOpPwd.TabIndex = 37;
            this.txtOpPwd.Text = "00";
            // 
            // txtOpTagPattern
            // 
            this.txtOpTagPattern.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtOpTagPattern.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtOpTagPattern.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtOpTagPattern.Location = new System.Drawing.Point(172, 58);
            this.txtOpTagPattern.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtOpTagPattern.Name = "txtOpTagPattern";
            this.txtOpTagPattern.Size = new System.Drawing.Size(254, 27);
            this.txtOpTagPattern.TabIndex = 36;
            // 
            // lblMemBankData
            // 
            this.lblMemBankData.AutoSize = true;
            this.lblMemBankData.Location = new System.Drawing.Point(18, 230);
            this.lblMemBankData.Name = "lblMemBankData";
            this.lblMemBankData.Size = new System.Drawing.Size(136, 20);
            this.lblMemBankData.TabIndex = 35;
            this.lblMemBankData.Text = "Memory Bank Data";
            // 
            // lblOpLength
            // 
            this.lblOpLength.AutoSize = true;
            this.lblOpLength.Location = new System.Drawing.Point(247, 129);
            this.lblOpLength.Name = "lblOpLength";
            this.lblOpLength.Size = new System.Drawing.Size(108, 20);
            this.lblOpLength.TabIndex = 34;
            this.lblOpLength.Text = "Length (words)";
            // 
            // lblOpOffset
            // 
            this.lblOpOffset.AutoSize = true;
            this.lblOpOffset.Location = new System.Drawing.Point(18, 129);
            this.lblOpOffset.Name = "lblOpOffset";
            this.lblOpOffset.Size = new System.Drawing.Size(103, 20);
            this.lblOpOffset.TabIndex = 33;
            this.lblOpOffset.Text = "Offset (words)";
            // 
            // lblOpMemBank
            // 
            this.lblOpMemBank.AutoSize = true;
            this.lblOpMemBank.Location = new System.Drawing.Point(18, 166);
            this.lblOpMemBank.Name = "lblOpMemBank";
            this.lblOpMemBank.Size = new System.Drawing.Size(100, 20);
            this.lblOpMemBank.TabIndex = 32;
            this.lblOpMemBank.Text = "Memory Bank";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(18, 93);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(118, 20);
            this.label12.TabIndex = 31;
            this.label12.Text = "Access Password";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(18, 58);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(82, 20);
            this.label13.TabIndex = 30;
            this.label13.Text = "Tag Pattern";
            // 
            // comboBoxReaders
            // 
            this.comboBoxReaders.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxReaders.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxReaders.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxReaders.FormattingEnabled = true;
            this.comboBoxReaders.IntegralHeight = false;
            this.comboBoxReaders.ItemHeight = 20;
            this.comboBoxReaders.Location = new System.Drawing.Point(23, 69);
            this.comboBoxReaders.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxReaders.Name = "comboBoxReaders";
            this.comboBoxReaders.Size = new System.Drawing.Size(429, 28);
            this.comboBoxReaders.TabIndex = 0;
            this.comboBoxReaders.SelectedIndexChanged += new System.EventHandler(this.ComboBoxReaders_SelectedIndexChanged);
            // 
            // btnConnectDisconnect
            // 
            this.btnConnectDisconnect.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnConnectDisconnect.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnConnectDisconnect.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnConnectDisconnect.BackgroundImage")));
            this.btnConnectDisconnect.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnConnectDisconnect.FlatAppearance.BorderSize = 0;
            this.btnConnectDisconnect.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnConnectDisconnect.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnConnectDisconnect.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnConnectDisconnect.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConnectDisconnect.ForeColor = System.Drawing.Color.White;
            this.btnConnectDisconnect.Location = new System.Drawing.Point(734, 65);
            this.btnConnectDisconnect.Margin = new System.Windows.Forms.Padding(4);
            this.btnConnectDisconnect.Name = "btnConnectDisconnect";
            this.btnConnectDisconnect.Size = new System.Drawing.Size(164, 34);
            this.btnConnectDisconnect.TabIndex = 1;
            this.btnConnectDisconnect.Text = "CONNECT";
            this.btnConnectDisconnect.UseVisualStyleBackColor = false;
            this.btnConnectDisconnect.Click += new System.EventHandler(this.BtnConnectDisconnect_Click);
            // 
            // lblReaders
            // 
            this.lblReaders.AutoSize = true;
            this.lblReaders.BackColor = System.Drawing.Color.Transparent;
            this.lblReaders.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReaders.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblReaders.Location = new System.Drawing.Point(20, 47);
            this.lblReaders.Margin = new System.Windows.Forms.Padding(0);
            this.lblReaders.Name = "lblReaders";
            this.lblReaders.Size = new System.Drawing.Size(145, 18);
            this.lblReaders.TabIndex = 10;
            this.lblReaders.Text = "Active RFID Readers";
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("menuStrip1.BackgroundImage")));
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.settingsMenuItem,
            this.helpMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(939, 28);
            this.menuStrip1.TabIndex = 19;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // settingsMenuItem
            // 
            this.settingsMenuItem.Checked = true;
            this.settingsMenuItem.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.settingsMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.antennaConfiguration,
            this.capabilitiesMenuItem,
            this.regulatory,
            this.preFilters,
            this.singulationMenuItem,
            this.tagReportingMenuItem,
            this.triggersMenuItem,
            this.configurationMenuItem,
            this.networkMenuItem,
            this.wpaConfigMenuItem,
            this.toolStripSeparator1,
            this.versionMenuItem,
            this.toolStripMenuItem1,
            this.saveConfigMenuItem});
            this.settingsMenuItem.Name = "settingsMenuItem";
            this.settingsMenuItem.Size = new System.Drawing.Size(76, 24);
            this.settingsMenuItem.Text = "&Settings";
            // 
            // antennaConfiguration
            // 
            this.antennaConfiguration.Name = "antennaConfiguration";
            this.antennaConfiguration.Size = new System.Drawing.Size(243, 26);
            this.antennaConfiguration.Text = "Antenna";
            this.antennaConfiguration.Click += new System.EventHandler(this.antennaConfiguration_Click);
            // 
            // capabilitiesMenuItem
            // 
            this.capabilitiesMenuItem.Name = "capabilitiesMenuItem";
            this.capabilitiesMenuItem.Size = new System.Drawing.Size(243, 26);
            this.capabilitiesMenuItem.Text = "Capabilities";
            this.capabilitiesMenuItem.Click += new System.EventHandler(this.CapabilitiesToolStripMenuItem_Click);
            // 
            // regulatory
            // 
            this.regulatory.Name = "regulatory";
            this.regulatory.Size = new System.Drawing.Size(243, 26);
            this.regulatory.Text = "Regulatory";
            this.regulatory.Click += new System.EventHandler(this.regulatory_Click);
            // 
            // preFilters
            // 
            this.preFilters.Name = "preFilters";
            this.preFilters.Size = new System.Drawing.Size(243, 26);
            this.preFilters.Text = "Pre Filters";
            this.preFilters.Click += new System.EventHandler(this.preFilters_Click);
            // 
            // singulationMenuItem
            // 
            this.singulationMenuItem.Name = "singulationMenuItem";
            this.singulationMenuItem.Size = new System.Drawing.Size(243, 26);
            this.singulationMenuItem.Text = "Singulation";
            this.singulationMenuItem.Click += new System.EventHandler(this.SingulationToolStripMenuItem_Click);
            // 
            // tagReportingMenuItem
            // 
            this.tagReportingMenuItem.Name = "tagReportingMenuItem";
            this.tagReportingMenuItem.Size = new System.Drawing.Size(243, 26);
            this.tagReportingMenuItem.Text = "Tag Reporting";
            this.tagReportingMenuItem.Click += new System.EventHandler(this.TagReportingMenuItem_Click);
            // 
            // triggersMenuItem
            // 
            this.triggersMenuItem.Name = "triggersMenuItem";
            this.triggersMenuItem.Size = new System.Drawing.Size(243, 26);
            this.triggersMenuItem.Text = "Triggers";
            this.triggersMenuItem.Click += new System.EventHandler(this.TriggersToolStripMenuItem_Click);
            // 
            // configurationMenuItem
            // 
            this.configurationMenuItem.Name = "configurationMenuItem";
            this.configurationMenuItem.Size = new System.Drawing.Size(243, 26);
            this.configurationMenuItem.Text = "Configuration";
            this.configurationMenuItem.Click += new System.EventHandler(this.Configurations_Click);
            // 
            // networkMenuItem
            // 
            this.networkMenuItem.Name = "networkMenuItem";
            this.networkMenuItem.Size = new System.Drawing.Size(243, 26);
            this.networkMenuItem.Text = "Network Configuration";
            this.networkMenuItem.Click += new System.EventHandler(this.networkMenuItem_Click);
            // 
            // wpaConfigMenuItem
            // 
            this.wpaConfigMenuItem.Name = "wpaConfigMenuItem";
            this.wpaConfigMenuItem.Size = new System.Drawing.Size(243, 26);
            this.wpaConfigMenuItem.Text = "WPA Configuration";
            this.wpaConfigMenuItem.Click += new System.EventHandler(this.wpaConfigMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(240, 6);
            // 
            // versionMenuItem
            // 
            this.versionMenuItem.Name = "versionMenuItem";
            this.versionMenuItem.Size = new System.Drawing.Size(243, 26);
            this.versionMenuItem.Text = "Version Info";
            this.versionMenuItem.Click += new System.EventHandler(this.versionMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(243, 26);
            this.toolStripMenuItem1.Text = "Restore Default";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.BtnRestoreDefaults_Click);
            // 
            // saveConfigMenuItem
            // 
            this.saveConfigMenuItem.Name = "saveConfigMenuItem";
            this.saveConfigMenuItem.Size = new System.Drawing.Size(243, 26);
            this.saveConfigMenuItem.Text = "Save Configuration";
            this.saveConfigMenuItem.Click += new System.EventHandler(this.BtnSaveConfig_Click);
            // 
            // helpMenuItem
            // 
            this.helpMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.helpMenuItem.Name = "helpMenuItem";
            this.helpMenuItem.Size = new System.Drawing.Size(55, 24);
            this.helpMenuItem.Text = "&Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(133, 26);
            this.aboutToolStripMenuItem.Text = "&About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.AboutToolStripMenuItem_Click);
            // 
            // btnPairNew
            // 
            this.btnPairNew.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPairNew.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnPairNew.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPairNew.BackgroundImage")));
            this.btnPairNew.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnPairNew.FlatAppearance.BorderSize = 0;
            this.btnPairNew.FlatAppearance.MouseDownBackColor = System.Drawing.Color.CornflowerBlue;
            this.btnPairNew.FlatAppearance.MouseOverBackColor = System.Drawing.Color.CornflowerBlue;
            this.btnPairNew.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPairNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPairNew.ForeColor = System.Drawing.Color.White;
            this.btnPairNew.Location = new System.Drawing.Point(463, 65);
            this.btnPairNew.Margin = new System.Windows.Forms.Padding(4);
            this.btnPairNew.Name = "btnPairNew";
            this.btnPairNew.Size = new System.Drawing.Size(128, 34);
            this.btnPairNew.TabIndex = 31;
            this.btnPairNew.Text = "PAIR";
            this.btnPairNew.UseVisualStyleBackColor = false;
            this.btnPairNew.Click += new System.EventHandler(this.BtnPairNew_Click);
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Location = new System.Drawing.Point(20, 591);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 20);
            this.label3.TabIndex = 46;
            this.label3.Text = "Battery Level :";
            // 
            // lblTemperature
            // 
            this.lblTemperature.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblTemperature.AutoSize = true;
            this.lblTemperature.BackColor = System.Drawing.Color.Transparent;
            this.lblTemperature.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTemperature.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblTemperature.Location = new System.Drawing.Point(421, 591);
            this.lblTemperature.Name = "lblTemperature";
            this.lblTemperature.Size = new System.Drawing.Size(30, 20);
            this.lblTemperature.TabIndex = 47;
            this.lblTemperature.Text = "0 C";
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.Location = new System.Drawing.Point(267, 591);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(143, 20);
            this.label5.TabIndex = 48;
            this.label5.Text = "Radio Temperature :";
            // 
            // lblBatteryLevel
            // 
            this.lblBatteryLevel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblBatteryLevel.AutoSize = true;
            this.lblBatteryLevel.BackColor = System.Drawing.Color.Transparent;
            this.lblBatteryLevel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBatteryLevel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblBatteryLevel.Location = new System.Drawing.Point(133, 591);
            this.lblBatteryLevel.Name = "lblBatteryLevel";
            this.lblBatteryLevel.Size = new System.Drawing.Size(29, 20);
            this.lblBatteryLevel.TabIndex = 49;
            this.lblBatteryLevel.Text = "0%";
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label6.Location = new System.Drawing.Point(600, 591);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 20);
            this.label6.TabIndex = 51;
            this.label6.Text = "Power :";
            // 
            // lblPower
            // 
            this.lblPower.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblPower.AutoSize = true;
            this.lblPower.BackColor = System.Drawing.Color.Transparent;
            this.lblPower.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPower.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblPower.Location = new System.Drawing.Point(667, 591);
            this.lblPower.Name = "lblPower";
            this.lblPower.Size = new System.Drawing.Size(28, 20);
            this.lblPower.TabIndex = 50;
            this.lblPower.Text = "0 v";
            // 
            // btnManualConnect
            // 
            this.btnManualConnect.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnManualConnect.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnManualConnect.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnManualConnect.BackgroundImage")));
            this.btnManualConnect.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnManualConnect.FlatAppearance.BorderSize = 0;
            this.btnManualConnect.FlatAppearance.MouseDownBackColor = System.Drawing.Color.CornflowerBlue;
            this.btnManualConnect.FlatAppearance.MouseOverBackColor = System.Drawing.Color.CornflowerBlue;
            this.btnManualConnect.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnManualConnect.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnManualConnect.ForeColor = System.Drawing.Color.White;
            this.btnManualConnect.Location = new System.Drawing.Point(598, 65);
            this.btnManualConnect.Margin = new System.Windows.Forms.Padding(4);
            this.btnManualConnect.Name = "btnManualConnect";
            this.btnManualConnect.Size = new System.Drawing.Size(128, 34);
            this.btnManualConnect.TabIndex = 52;
            this.btnManualConnect.Text = "IP / COM";
            this.btnManualConnect.UseVisualStyleBackColor = false;
            this.btnManualConnect.Click += new System.EventHandler(this.btnManualConnect_Click);
            // 
            // lblLog
            // 
            this.lblLog.AutoSize = true;
            this.lblLog.BackColor = System.Drawing.Color.Transparent;
            this.lblLog.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLog.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblLog.Location = new System.Drawing.Point(20, 409);
            this.lblLog.Name = "lblLog";
            this.lblLog.Size = new System.Drawing.Size(34, 20);
            this.lblLog.TabIndex = 16;
            this.lblLog.Text = "Log";
            this.lblLog.Click += new System.EventHandler(this.lblLog_Click);
            // 
            // txtOutput
            // 
            this.txtOutput.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtOutput.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtOutput.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOutput.Location = new System.Drawing.Point(23, 433);
            this.txtOutput.Margin = new System.Windows.Forms.Padding(4);
            this.txtOutput.Multiline = true;
            this.txtOutput.Name = "txtOutput";
            this.txtOutput.ReadOnly = true;
            this.txtOutput.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtOutput.Size = new System.Drawing.Size(892, 150);
            this.txtOutput.TabIndex = 5;
            this.txtOutput.TabStop = false;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(939, 617);
            this.Controls.Add(this.btnManualConnect);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lblPower);
            this.Controls.Add(this.lblBatteryLevel);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblTemperature);
            this.Controls.Add(this.label3);
            this.Controls.Add(tabContainer);
            this.Controls.Add(this.btnConnectDisconnect);
            this.Controls.Add(this.btnPairNew);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.lblLog);
            this.Controls.Add(this.lblReaders);
            this.Controls.Add(this.txtOutput);
            this.Controls.Add(this.comboBoxReaders);
            this.DoubleBuffered = true;
            this.ForeColor = System.Drawing.Color.Black;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(954, 654);
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RFID SDK DEMONSTRATION APP";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmAppMain_FormClosing);
            this.Load += new System.EventHandler(this.FrmAppMain_Load);
            tabContainer.ResumeLayout(false);
            this.tabInventory.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdTags)).EndInit();
            this.tabTagLocate.ResumeLayout(false);
            this.tabTagLocate.PerformLayout();
            this.tabReadWrite.ResumeLayout(false);
            this.tabReadWrite.PerformLayout();
            this.tabLock.ResumeLayout(false);
            this.tabLock.PerformLayout();
            this.tabKill.ResumeLayout(false);
            this.tabKill.PerformLayout();
            this.tabRSM.ResumeLayout(false);
            this.tabRSM.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ComboBox comboBoxReaders;
        private Button btnConnectDisconnect;
        private Button btnInventoryStart;
        private Button btnInventoryStop;
        private Label lblReaders;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem settingsMenuItem;
        private ToolStripMenuItem configurationMenuItem;
        private ToolStripMenuItem helpMenuItem;
        private ToolStripMenuItem aboutToolStripMenuItem;
        private Button btnPairNew;
        private Button btnPurgeTags;
        private ToolStripMenuItem capabilitiesMenuItem;
        private ToolStripMenuItem singulationMenuItem;
        private ToolStripMenuItem triggersMenuItem;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripMenuItem saveConfigMenuItem;
        private ToolStripMenuItem toolStripMenuItem1;
        private ToolStripMenuItem tagReportingMenuItem;
        private TabPage tabInventory;
        private TabPage tabTagLocate;
        private Button btnTagLocateStart;
        private Button btnTagLocateStop;
        private ProgressBar proximityPercentBar;
        private Label lblTL;
        private Label label2;
        private TextBox txtTagId;
        private ToolStripMenuItem antennaConfiguration;
        private ToolStripMenuItem regulatory;
        private ToolStripMenuItem preFilters;
        private TabPage tabReadWrite;
        private ToolStripMenuItem versionMenuItem;
        private Label label3;
        private Label lblTemperature;
        private Label label5;
        private Label lblBatteryLevel;
        private Label label6;
        private Label lblPower;
        private Button btnManualConnect;
        private TabPage tabLock;
        private TabPage tabKill;
        private TabPage tabRSM;
        private Button btnWrite;
        private Button btnRead;
        private TextBox txtData;
        private TextBox txtLength;
        private TextBox txtOffset;
        private ComboBox cmbMemoryBank;
        private TextBox txtPassword;
        private TextBox txtTagPattern;
        private Label labelData;
        private Label labelLength;
        private Label labelOffset;
        private Label labelMemBank;
        private Label labelPassword;
        private Label labelTagPattern;
        private Button btnLock;
        private ComboBox cmbLockPrivilege;
        private ComboBox cmbMemoryBankLock;
        private TextBox txtPasswordLock;
        private TextBox txtTagPatternLock;
        private Label labelLockPrivilege;
        private Label labelMemBankACLock;
        private Label labelPasswordACLock;
        private Label labelTagPatternACLock;
        private Button btnKill;
        private TextBox txtPasswordKill;
        private TextBox txtTagPatternKill;
        private Label labelKillPassword;
        private Label labelTagPatternKill;
        private Button btnSetAttribute;
        private Button btnGetAttribute;
        private TextBox txtValue;
        private TextBox txtAttribute;
        private Label label4;
        private Label label7;
        private Label label8;
        private TextBox txtType;
        private ToolStripMenuItem networkMenuItem;
        private ToolStripMenuItem wpaConfigMenuItem;
        private Button btnExecuteOperationSequence;
        private DataGridView grdTags;
        private TabPage tabPage1;
        private Label label14;
        private ComboBox cboTagOperation;
        private Button btnAddSequenceOperation;
        private TextBox txtOpMemBankData;
        private TextBox txtOpLength;
        private TextBox txtOpOffset;
        private ComboBox cboOpMemBank;
        private TextBox txtOpPwd;
        private TextBox txtOpTagPattern;
        private Label lblMemBankData;
        private Label lblOpLength;
        private Label lblOpOffset;
        private Label lblOpMemBank;
        private Label label12;
        private Label label13;
        private Button btnEndSequenceOperation;
        private Button btnBeginSequenceOperation;
        private Label lblLog;
        private TextBox txtOutput;
        private ComboBox cboOpLockMemoryBank;
        private Label lblLockMemBank;
        private ComboBox cboOpLockPermission;
        private Label lblLockPrivilege;
        private Button btnClearSequenceOperation;
    }
}

