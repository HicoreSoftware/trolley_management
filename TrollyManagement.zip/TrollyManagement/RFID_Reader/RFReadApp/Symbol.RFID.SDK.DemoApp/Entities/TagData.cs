﻿namespace Symbol.RFID.SDK.DemoApp.Entities
{
    public class TagData
    {
        #region Private Fields
        private string tagId;
        private sbyte peakRSSI;
        private ushort tagSeenCount;
        private ushort antennaID;
        private long tagSeenTotalCount = 0;
        private string accessOperations = "";
        #endregion

        #region Public Properties

        
        /// <summary>
        /// Gets the Tag ID 
        /// </summary>
        public string TagID { get => tagId; set => tagId = value; }

        /// <summary>
        /// Gets the Peak RSSI 
        /// </summary>
        public sbyte PeakRSSI { get => peakRSSI; set => peakRSSI = value; }

        /// <summary>
        /// Gets the antenna ID on which this tag is seen
        /// </summary>
        public ushort AntennaID { get => antennaID; set => antennaID = value; }

        /// <summary>
        /// Gets the Tag seen count
        /// </summary>
        public ushort TagSeenCount { get => tagSeenCount; set => tagSeenCount = value; }

        /// <summary>
        /// Tag Seen Total Count
        /// </summary>
        public long TagSeenTotalCount { get => tagSeenTotalCount; set => tagSeenTotalCount = value; }
      
        /// <summary>
        /// Taf Access operations
        /// </summary>
        public string AccessOperations { get => accessOperations; set => accessOperations = value; }

        #endregion
    }
}
