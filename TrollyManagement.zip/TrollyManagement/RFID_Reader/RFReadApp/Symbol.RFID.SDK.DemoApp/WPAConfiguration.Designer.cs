﻿
namespace Symbol.RFID.SDK.DemoApp
{
    partial class WPAConfiguration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpCapabilities = new System.Windows.Forms.GroupBox();
            this.txtStatus = new System.Windows.Forms.TextBox();
            this.txtWiFi = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnWiFiDisable = new System.Windows.Forms.Button();
            this.btnWiFiDisconnect = new System.Windows.Forms.Button();
            this.txtMac = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtWiFiSsid = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.brnWiFiSave = new System.Windows.Forms.Button();
            this.chkSelectedEntry = new System.Windows.Forms.CheckBox();
            this.btnConnect = new System.Windows.Forms.Button();
            this.chkAll = new System.Windows.Forms.CheckBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.comboBoxEntries = new System.Windows.Forms.ComboBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtSSID = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnClearScan = new System.Windows.Forms.Button();
            this.grdWifi = new System.Windows.Forms.DataGridView();
            this.btnScan = new System.Windows.Forms.Button();
            this.grpCapabilities.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdWifi)).BeginInit();
            this.SuspendLayout();
            // 
            // grpCapabilities
            // 
            this.grpCapabilities.BackColor = System.Drawing.Color.Transparent;
            this.grpCapabilities.Controls.Add(this.txtStatus);
            this.grpCapabilities.Controls.Add(this.txtWiFi);
            this.grpCapabilities.Controls.Add(this.label8);
            this.grpCapabilities.Controls.Add(this.lbl2);
            this.grpCapabilities.Controls.Add(this.label7);
            this.grpCapabilities.Controls.Add(this.btnWiFiDisable);
            this.grpCapabilities.Controls.Add(this.btnWiFiDisconnect);
            this.grpCapabilities.Controls.Add(this.txtMac);
            this.grpCapabilities.Controls.Add(this.label1);
            this.grpCapabilities.Controls.Add(this.txtWiFiSsid);
            this.grpCapabilities.ForeColor = System.Drawing.SystemColors.Desktop;
            this.grpCapabilities.Location = new System.Drawing.Point(12, 11);
            this.grpCapabilities.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpCapabilities.Name = "grpCapabilities";
            this.grpCapabilities.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpCapabilities.Size = new System.Drawing.Size(437, 164);
            this.grpCapabilities.TabIndex = 0;
            this.grpCapabilities.TabStop = false;
            this.grpCapabilities.Text = "WiFi Status";
            // 
            // txtStatus
            // 
            this.txtStatus.BackColor = System.Drawing.SystemColors.Window;
            this.txtStatus.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStatus.Location = new System.Drawing.Point(187, 59);
            this.txtStatus.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.ReadOnly = true;
            this.txtStatus.Size = new System.Drawing.Size(129, 27);
            this.txtStatus.TabIndex = 2;
            this.txtStatus.TabStop = false;
            // 
            // txtWiFi
            // 
            this.txtWiFi.BackColor = System.Drawing.SystemColors.Window;
            this.txtWiFi.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWiFi.Location = new System.Drawing.Point(187, 25);
            this.txtWiFi.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtWiFi.Name = "txtWiFi";
            this.txtWiFi.ReadOnly = true;
            this.txtWiFi.Size = new System.Drawing.Size(129, 27);
            this.txtWiFi.TabIndex = 0;
            this.txtWiFi.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(20, 128);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(40, 20);
            this.label8.TabIndex = 9;
            this.label8.Text = "SSID";
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2.Location = new System.Drawing.Point(20, 65);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(49, 20);
            this.lbl2.TabIndex = 7;
            this.lbl2.Text = "Status";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(20, 97);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(98, 20);
            this.label7.TabIndex = 8;
            this.label7.Text = "MAC Address";
            // 
            // btnWiFiDisable
            // 
            this.btnWiFiDisable.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnWiFiDisable.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWiFiDisable.Location = new System.Drawing.Point(322, 23);
            this.btnWiFiDisable.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnWiFiDisable.Name = "btnWiFiDisable";
            this.btnWiFiDisable.Size = new System.Drawing.Size(104, 30);
            this.btnWiFiDisable.TabIndex = 1;
            this.btnWiFiDisable.Text = "Disable";
            this.btnWiFiDisable.UseVisualStyleBackColor = false;
            this.btnWiFiDisable.Click += new System.EventHandler(this.btnWiFiDisable_Click);
            // 
            // btnWiFiDisconnect
            // 
            this.btnWiFiDisconnect.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnWiFiDisconnect.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWiFiDisconnect.Location = new System.Drawing.Point(322, 57);
            this.btnWiFiDisconnect.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnWiFiDisconnect.Name = "btnWiFiDisconnect";
            this.btnWiFiDisconnect.Size = new System.Drawing.Size(104, 30);
            this.btnWiFiDisconnect.TabIndex = 3;
            this.btnWiFiDisconnect.Text = "Disconnect";
            this.btnWiFiDisconnect.UseVisualStyleBackColor = false;
            this.btnWiFiDisconnect.Click += new System.EventHandler(this.btnWiFiDisconnect_Click);
            // 
            // txtMac
            // 
            this.txtMac.BackColor = System.Drawing.SystemColors.Window;
            this.txtMac.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMac.Location = new System.Drawing.Point(187, 91);
            this.txtMac.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtMac.Name = "txtMac";
            this.txtMac.ReadOnly = true;
            this.txtMac.Size = new System.Drawing.Size(239, 27);
            this.txtMac.TabIndex = 4;
            this.txtMac.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(20, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 20);
            this.label1.TabIndex = 6;
            this.label1.Text = "WiFi";
            // 
            // txtWiFiSsid
            // 
            this.txtWiFiSsid.BackColor = System.Drawing.SystemColors.Window;
            this.txtWiFiSsid.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWiFiSsid.Location = new System.Drawing.Point(187, 122);
            this.txtWiFiSsid.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtWiFiSsid.Name = "txtWiFiSsid";
            this.txtWiFiSsid.ReadOnly = true;
            this.txtWiFiSsid.Size = new System.Drawing.Size(239, 27);
            this.txtWiFiSsid.TabIndex = 5;
            this.txtWiFiSsid.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.brnWiFiSave);
            this.groupBox1.Controls.Add(this.chkSelectedEntry);
            this.groupBox1.Controls.Add(this.btnConnect);
            this.groupBox1.Controls.Add(this.chkAll);
            this.groupBox1.Controls.Add(this.btnDelete);
            this.groupBox1.Controls.Add(this.btnAdd);
            this.groupBox1.Controls.Add(this.comboBoxEntries);
            this.groupBox1.Controls.Add(this.txtPassword);
            this.groupBox1.Controls.Add(this.txtSSID);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.Desktop;
            this.groupBox1.Location = new System.Drawing.Point(12, 179);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(437, 262);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Basic Service Set";
            // 
            // brnWiFiSave
            // 
            this.brnWiFiSave.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.brnWiFiSave.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.brnWiFiSave.Location = new System.Drawing.Point(322, 223);
            this.brnWiFiSave.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.brnWiFiSave.Name = "brnWiFiSave";
            this.brnWiFiSave.Size = new System.Drawing.Size(104, 30);
            this.brnWiFiSave.TabIndex = 11;
            this.brnWiFiSave.Text = "Save";
            this.brnWiFiSave.UseVisualStyleBackColor = false;
            this.brnWiFiSave.Click += new System.EventHandler(this.brnWiFiSave_Click);
            // 
            // chkSelectedEntry
            // 
            this.chkSelectedEntry.AutoSize = true;
            this.chkSelectedEntry.Location = new System.Drawing.Point(187, 196);
            this.chkSelectedEntry.Name = "chkSelectedEntry";
            this.chkSelectedEntry.Size = new System.Drawing.Size(116, 20);
            this.chkSelectedEntry.TabIndex = 6;
            this.chkSelectedEntry.Text = "Selected Entry";
            this.chkSelectedEntry.UseVisualStyleBackColor = true;
            // 
            // btnConnect
            // 
            this.btnConnect.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnConnect.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConnect.Location = new System.Drawing.Point(322, 189);
            this.btnConnect.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(104, 30);
            this.btnConnect.TabIndex = 7;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = false;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // chkAll
            // 
            this.chkAll.AutoSize = true;
            this.chkAll.Location = new System.Drawing.Point(187, 162);
            this.chkAll.Name = "chkAll";
            this.chkAll.Size = new System.Drawing.Size(88, 20);
            this.chkAll.TabIndex = 4;
            this.chkAll.Text = "All Entries";
            this.chkAll.UseVisualStyleBackColor = true;
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnDelete.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Location = new System.Drawing.Point(322, 155);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(104, 30);
            this.btnDelete.TabIndex = 5;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnAdd.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Location = new System.Drawing.Point(322, 121);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(104, 30);
            this.btnAdd.TabIndex = 3;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // comboBoxEntries
            // 
            this.comboBoxEntries.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxEntries.FormattingEnabled = true;
            this.comboBoxEntries.Location = new System.Drawing.Point(187, 25);
            this.comboBoxEntries.Name = "comboBoxEntries";
            this.comboBoxEntries.Size = new System.Drawing.Size(239, 28);
            this.comboBoxEntries.TabIndex = 0;
            this.comboBoxEntries.SelectedIndexChanged += new System.EventHandler(this.comboBoxEntries_SelectedIndexChanged);
            // 
            // txtPassword
            // 
            this.txtPassword.BackColor = System.Drawing.SystemColors.Window;
            this.txtPassword.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPassword.Location = new System.Drawing.Point(187, 90);
            this.txtPassword.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(239, 27);
            this.txtPassword.TabIndex = 2;
            // 
            // txtSSID
            // 
            this.txtSSID.BackColor = System.Drawing.SystemColors.Window;
            this.txtSSID.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSSID.Location = new System.Drawing.Point(187, 58);
            this.txtSSID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtSSID.Name = "txtSSID";
            this.txtSSID.Size = new System.Drawing.Size(239, 27);
            this.txtSSID.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(20, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 20);
            this.label3.TabIndex = 10;
            this.label3.Text = "Password";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(20, 64);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 20);
            this.label4.TabIndex = 9;
            this.label4.Text = "SSID";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(20, 31);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 20);
            this.label5.TabIndex = 8;
            this.label5.Text = "Entries";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.btnClearScan);
            this.groupBox2.Controls.Add(this.grdWifi);
            this.groupBox2.Controls.Add(this.btnScan);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.Desktop;
            this.groupBox2.Location = new System.Drawing.Point(464, 19);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Size = new System.Drawing.Size(602, 422);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "WiFi Scan";
            // 
            // btnClearScan
            // 
            this.btnClearScan.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnClearScan.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearScan.Location = new System.Drawing.Point(481, 383);
            this.btnClearScan.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnClearScan.Name = "btnClearScan";
            this.btnClearScan.Size = new System.Drawing.Size(104, 30);
            this.btnClearScan.TabIndex = 12;
            this.btnClearScan.Text = "Clear";
            this.btnClearScan.UseVisualStyleBackColor = false;
            this.btnClearScan.Click += new System.EventHandler(this.btnClearScan_Click);
            // 
            // grdWifi
            // 
            this.grdWifi.AllowUserToAddRows = false;
            this.grdWifi.AllowUserToDeleteRows = false;
            this.grdWifi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdWifi.Location = new System.Drawing.Point(27, 54);
            this.grdWifi.Name = "grdWifi";
            this.grdWifi.ReadOnly = true;
            this.grdWifi.RowHeadersWidth = 51;
            this.grdWifi.RowTemplate.Height = 24;
            this.grdWifi.Size = new System.Drawing.Size(558, 322);
            this.grdWifi.TabIndex = 11;
            // 
            // btnScan
            // 
            this.btnScan.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnScan.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnScan.Location = new System.Drawing.Point(481, 19);
            this.btnScan.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnScan.Name = "btnScan";
            this.btnScan.Size = new System.Drawing.Size(104, 30);
            this.btnScan.TabIndex = 10;
            this.btnScan.Text = "Scan";
            this.btnScan.UseVisualStyleBackColor = false;
            this.btnScan.Click += new System.EventHandler(this.btnScan_Click);
            // 
            // WPAConfiguration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1078, 453);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.grpCapabilities);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "WPAConfiguration";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "WPA Configuration";
            this.Load += new System.EventHandler(this.WAPConfiguration_Load);
            this.grpCapabilities.ResumeLayout(false);
            this.grpCapabilities.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdWifi)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpCapabilities;
        private System.Windows.Forms.TextBox txtWiFiSsid;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtMac;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtSSID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBoxEntries;
        private System.Windows.Forms.Button btnWiFiDisable;
        private System.Windows.Forms.Button btnWiFiDisconnect;
        private System.Windows.Forms.TextBox txtStatus;
        private System.Windows.Forms.TextBox txtWiFi;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.CheckBox chkSelectedEntry;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.CheckBox chkAll;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnClearScan;
        private System.Windows.Forms.DataGridView grdWifi;
        private System.Windows.Forms.Button btnScan;
        private System.Windows.Forms.Button brnWiFiSave;
    }
}