﻿namespace Symbol.RFID.SDK.DemoApp
{
    partial class Configuration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Configuration));
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.cmbBeeperVolume = new System.Windows.Forms.ComboBox();
            this.btnSetBeeperVolume = new System.Windows.Forms.Button();
            this.btnGetBeeperVolume = new System.Windows.Forms.Button();
            this.gbPowerManagement = new System.Windows.Forms.GroupBox();
            this.btnSetDP = new System.Windows.Forms.Button();
            this.btnGetDP = new System.Windows.Forms.Button();
            this.cbDynamicPower = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cmbTriggerMode = new System.Windows.Forms.ComboBox();
            this.btnTriggerModeSet = new System.Windows.Forms.Button();
            this.btnTriggerModeGet = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cmbLowerTrigger = new System.Windows.Forms.ComboBox();
            this.cmbUpperTrigger = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox4.SuspendLayout();
            this.gbPowerManagement.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox4.BackColor = System.Drawing.Color.Transparent;
            this.groupBox4.Controls.Add(this.cmbBeeperVolume);
            this.groupBox4.Controls.Add(this.btnSetBeeperVolume);
            this.groupBox4.Controls.Add(this.btnGetBeeperVolume);
            this.groupBox4.ForeColor = System.Drawing.SystemColors.Desktop;
            this.groupBox4.Location = new System.Drawing.Point(15, 14);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox4.Size = new System.Drawing.Size(348, 69);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Beeper Volume";
            // 
            // cmbBeeperVolume
            // 
            this.cmbBeeperVolume.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBeeperVolume.FormattingEnabled = true;
            this.cmbBeeperVolume.Location = new System.Drawing.Point(15, 28);
            this.cmbBeeperVolume.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbBeeperVolume.Name = "cmbBeeperVolume";
            this.cmbBeeperVolume.Size = new System.Drawing.Size(192, 24);
            this.cmbBeeperVolume.TabIndex = 0;
            // 
            // btnSetBeeperVolume
            // 
            this.btnSetBeeperVolume.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSetBeeperVolume.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnSetBeeperVolume.Location = new System.Drawing.Point(280, 27);
            this.btnSetBeeperVolume.Margin = new System.Windows.Forms.Padding(4);
            this.btnSetBeeperVolume.Name = "btnSetBeeperVolume";
            this.btnSetBeeperVolume.Size = new System.Drawing.Size(61, 28);
            this.btnSetBeeperVolume.TabIndex = 2;
            this.btnSetBeeperVolume.Text = "Set";
            this.btnSetBeeperVolume.UseVisualStyleBackColor = true;
            this.btnSetBeeperVolume.Click += new System.EventHandler(this.BtnSetBeeperVolume_Click);
            // 
            // btnGetBeeperVolume
            // 
            this.btnGetBeeperVolume.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGetBeeperVolume.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnGetBeeperVolume.Location = new System.Drawing.Point(212, 27);
            this.btnGetBeeperVolume.Margin = new System.Windows.Forms.Padding(4);
            this.btnGetBeeperVolume.Name = "btnGetBeeperVolume";
            this.btnGetBeeperVolume.Size = new System.Drawing.Size(60, 28);
            this.btnGetBeeperVolume.TabIndex = 1;
            this.btnGetBeeperVolume.Text = "Get";
            this.btnGetBeeperVolume.UseVisualStyleBackColor = true;
            this.btnGetBeeperVolume.Click += new System.EventHandler(this.BtnGetBeeperVolume_Click);
            // 
            // gbPowerManagement
            // 
            this.gbPowerManagement.BackColor = System.Drawing.Color.Transparent;
            this.gbPowerManagement.Controls.Add(this.btnSetDP);
            this.gbPowerManagement.Controls.Add(this.btnGetDP);
            this.gbPowerManagement.Controls.Add(this.cbDynamicPower);
            this.gbPowerManagement.Location = new System.Drawing.Point(12, 287);
            this.gbPowerManagement.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbPowerManagement.Name = "gbPowerManagement";
            this.gbPowerManagement.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbPowerManagement.Size = new System.Drawing.Size(348, 60);
            this.gbPowerManagement.TabIndex = 2;
            this.gbPowerManagement.TabStop = false;
            this.gbPowerManagement.Text = "Power Management";
            // 
            // btnSetDP
            // 
            this.btnSetDP.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSetDP.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnSetDP.Location = new System.Drawing.Point(280, 22);
            this.btnSetDP.Margin = new System.Windows.Forms.Padding(4);
            this.btnSetDP.Name = "btnSetDP";
            this.btnSetDP.Size = new System.Drawing.Size(61, 28);
            this.btnSetDP.TabIndex = 2;
            this.btnSetDP.TabStop = false;
            this.btnSetDP.Text = "Set";
            this.btnSetDP.UseVisualStyleBackColor = true;
            this.btnSetDP.Click += new System.EventHandler(this.btnSetDP_Click);
            // 
            // btnGetDP
            // 
            this.btnGetDP.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGetDP.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnGetDP.Location = new System.Drawing.Point(212, 22);
            this.btnGetDP.Margin = new System.Windows.Forms.Padding(4);
            this.btnGetDP.Name = "btnGetDP";
            this.btnGetDP.Size = new System.Drawing.Size(60, 28);
            this.btnGetDP.TabIndex = 1;
            this.btnGetDP.TabStop = false;
            this.btnGetDP.Text = "Get";
            this.btnGetDP.UseVisualStyleBackColor = true;
            this.btnGetDP.Click += new System.EventHandler(this.btnGetDP_Click);
            // 
            // cbDynamicPower
            // 
            this.cbDynamicPower.AutoSize = true;
            this.cbDynamicPower.Location = new System.Drawing.Point(15, 27);
            this.cbDynamicPower.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbDynamicPower.Name = "cbDynamicPower";
            this.cbDynamicPower.Size = new System.Drawing.Size(123, 20);
            this.cbDynamicPower.TabIndex = 0;
            this.cbDynamicPower.Text = "Dynamic Power";
            this.cbDynamicPower.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.cmbTriggerMode);
            this.groupBox1.Controls.Add(this.btnTriggerModeSet);
            this.groupBox1.Controls.Add(this.btnTriggerModeGet);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.Desktop;
            this.groupBox1.Location = new System.Drawing.Point(16, 97);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(348, 69);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Trigger Mode";
            // 
            // cmbTriggerMode
            // 
            this.cmbTriggerMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTriggerMode.FormattingEnabled = true;
            this.cmbTriggerMode.Location = new System.Drawing.Point(15, 28);
            this.cmbTriggerMode.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbTriggerMode.Name = "cmbTriggerMode";
            this.cmbTriggerMode.Size = new System.Drawing.Size(192, 24);
            this.cmbTriggerMode.TabIndex = 0;
            // 
            // btnTriggerModeSet
            // 
            this.btnTriggerModeSet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnTriggerModeSet.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnTriggerModeSet.Location = new System.Drawing.Point(280, 27);
            this.btnTriggerModeSet.Margin = new System.Windows.Forms.Padding(4);
            this.btnTriggerModeSet.Name = "btnTriggerModeSet";
            this.btnTriggerModeSet.Size = new System.Drawing.Size(61, 28);
            this.btnTriggerModeSet.TabIndex = 2;
            this.btnTriggerModeSet.Text = "Set";
            this.btnTriggerModeSet.UseVisualStyleBackColor = true;
            this.btnTriggerModeSet.Click += new System.EventHandler(this.btnTriggerModeSet_Click);
            // 
            // btnTriggerModeGet
            // 
            this.btnTriggerModeGet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnTriggerModeGet.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnTriggerModeGet.Location = new System.Drawing.Point(212, 27);
            this.btnTriggerModeGet.Margin = new System.Windows.Forms.Padding(4);
            this.btnTriggerModeGet.Name = "btnTriggerModeGet";
            this.btnTriggerModeGet.Size = new System.Drawing.Size(60, 28);
            this.btnTriggerModeGet.TabIndex = 1;
            this.btnTriggerModeGet.Text = "Get";
            this.btnTriggerModeGet.UseVisualStyleBackColor = true;
            this.btnTriggerModeGet.Click += new System.EventHandler(this.btnTriggerModeGet_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.cmbLowerTrigger);
            this.groupBox2.Controls.Add(this.cmbUpperTrigger);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Location = new System.Drawing.Point(14, 186);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(348, 86);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Trigger Mapping";
            // 
            // cmbLowerTrigger
            // 
            this.cmbLowerTrigger.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLowerTrigger.FormattingEnabled = true;
            this.cmbLowerTrigger.Items.AddRange(new object[] {
            "RFID",
            "Sled Scanner",
            "Terminal Scanner",
            "Scan Notification",
            "No Action"});
            this.cmbLowerTrigger.Location = new System.Drawing.Point(172, 48);
            this.cmbLowerTrigger.Margin = new System.Windows.Forms.Padding(4);
            this.cmbLowerTrigger.Name = "cmbLowerTrigger";
            this.cmbLowerTrigger.Size = new System.Drawing.Size(167, 24);
            this.cmbLowerTrigger.TabIndex = 10;
            this.cmbLowerTrigger.SelectedIndexChanged += new System.EventHandler(this.CmbLowerTrigger_SelectedIndexChanged);
            // 
            // cmbUpperTrigger
            // 
            this.cmbUpperTrigger.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbUpperTrigger.FormattingEnabled = true;
            this.cmbUpperTrigger.Items.AddRange(new object[] {
            "RFID",
            "Sled Scanner",
            "Terminal Scanner",
            "Scan Notification",
            "No Action"});
            this.cmbUpperTrigger.Location = new System.Drawing.Point(15, 48);
            this.cmbUpperTrigger.Margin = new System.Windows.Forms.Padding(4);
            this.cmbUpperTrigger.Name = "cmbUpperTrigger";
            this.cmbUpperTrigger.Size = new System.Drawing.Size(149, 24);
            this.cmbUpperTrigger.TabIndex = 9;
            this.cmbUpperTrigger.SelectedIndexChanged += new System.EventHandler(this.CmbUpperTrigger_SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(14, 28);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(92, 16);
            this.label13.TabIndex = 8;
            this.label13.Text = "Upper Trigger";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(171, 28);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(90, 16);
            this.label12.TabIndex = 7;
            this.label12.Text = "Lower Trigger";
            // 
            // Configuration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(381, 362);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.gbPowerManagement);
            this.Controls.Add(this.groupBox4);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Configuration";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Configuration";
            this.Load += new System.EventHandler(this.Configuration_Load);
            this.groupBox4.ResumeLayout(false);
            this.gbPowerManagement.ResumeLayout(false);
            this.gbPowerManagement.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ComboBox cmbBeeperVolume;
        private System.Windows.Forms.Button btnSetBeeperVolume;
        private System.Windows.Forms.Button btnGetBeeperVolume;
        private System.Windows.Forms.GroupBox gbPowerManagement;
        private System.Windows.Forms.CheckBox cbDynamicPower;
        private System.Windows.Forms.Button btnSetDP;
        private System.Windows.Forms.Button btnGetDP;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cmbTriggerMode;
        private System.Windows.Forms.Button btnTriggerModeSet;
        private System.Windows.Forms.Button btnTriggerModeGet;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox cmbLowerTrigger;
        private System.Windows.Forms.ComboBox cmbUpperTrigger;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
    }
}