﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace RestAPIConnection
{
    /// <summary>
    /// 
    /// </summary>
    public class Trolleyinventory 
    {

        public Trolleyinventory(string scanid, string roomid, string trolleyid, DateTime inTime, DateTime outTime, string status = "")
		{
			ScannerID = scanid;
			RoomID = roomid;
			TrolleyID = trolleyid;
			InTime = inTime.ToString();
			OutTime = outTime.ToString();
			Status = status;
        }
			 
        #region Properties 
        private string scannerID;

		/// <summary>
		/// 
		/// </summary>
		public string ScannerID
		{
			get 
			{ 
				return scannerID; 
			}
			set 
			{ 
				scannerID = value; 
			}
		}

		private string roomID;

		public string RoomID
		{
			get { return roomID; }
			set { roomID = value; }
			
		}

		private string trolleyID;

		public string TrolleyID
		{
			get { return trolleyID; }
			set { trolleyID = value;  }
		}

		private string inTime;

		public string InTime
		{
			get { return inTime; }
			set { inTime = value; 
			}
		}

		private string outTime;

		public string OutTime
		{
			get { return outTime; }
			set { outTime = value; }
		}

		private string status;

		public string Status
		{
			get { return status; }
			set { status = value; }
		}

		public string GetJsonString()
		{
            return JsonConvert.SerializeObject(this);
		}
        #endregion 


    }
}
