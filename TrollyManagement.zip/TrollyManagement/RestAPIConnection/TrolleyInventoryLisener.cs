﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RestAPIConnection
{
    public class TrolleyInventoryLisener
    {
        public int TimeOut = 1000;
        public string InventryData { get; set; } = "";

        private Timer mUpdateTimer;

        public RestApiConnection mRestApiConnection { get; set; }
        public  TrolleyInventoryLisener()
        {
            Start();
          
        }
        public async void Start()
        {
            InventryData = await GetData();
            mUpdateTimer = new Timer(OnTimerEvent, null, 0, TimeOut);
        }

       
        private async void OnTimerEvent(object state)
        {
            var newInventory = await GetData();

            if (InventryData != newInventory)
            {
                InventryData = newInventory;
                RestApiConnection.Instance.UpdateTrolleyInventry(InventryData);
            }
        }

        public async Task<string> GetData()
        {
          var  data = await RestApiConnection.Instance.GetJsonStringAsync("trolleyInventory");
            return data;
        }

    }
}