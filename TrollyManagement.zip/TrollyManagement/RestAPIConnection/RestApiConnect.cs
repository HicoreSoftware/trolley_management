﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace RestAPIConnection
{
    public class RestApiConnection
    {
        private readonly HttpClient _httpClient = new HttpClient();
       
        private TrolleyInventoryLisener TrolleyInventoryLisen;

        // private string HostAddress = "http://127.0.0.1:5000";
        private string HostAddress = "http://hicoresoft.pythonanywhere.com";
        private  string RestApiAddress 
        {
            get; set; 
        }

        public RestApiConnection()
        {
            RestApiAddress = HostAddress;
        }
        public void Connect()
        {
            Start();
        }


        private static RestApiConnection instance = null;
        public static RestApiConnection Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new RestApiConnection();
                    // instance.

                }
                return instance;
            }
        }

        public void Start()
        {
            TrolleyInventoryLisen = new TrolleyInventoryLisener();
            TrolleyInventoryLisen.Start();
        }

        public async Task<string> GetJsonStringAsync(string endpoint)
        {
            string url = RestApiAddress + "/" + endpoint;
            string jsonContent = string.Empty;

            try
            {
             
                HttpResponseMessage response = await _httpClient.GetAsync(url);

                if (response.IsSuccessStatusCode)
                {
                    jsonContent = await response.Content.ReadAsStringAsync();
                }
                else
                {
                    // Handle API error here
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions here
            }

            return jsonContent;
        }

        public async Task<HttpResponseMessage> DeleteDataAsyc(string endpoint)
        {
            try
            {
                // string endpoint = "/room";
                string url = RestApiAddress + "/" + endpoint;
                HttpResponseMessage response = await _httpClient.DeleteAsync(url);

                return response;
            }
            catch (Exception ex)
            {
                // Handle exceptions here
                return null;
            }
        }

        public Action<string> OnUpdateTrolleyInventry { get; set; }

        public void UpdateTrolleyInventry(string inventryInfo)
        {
            if(OnUpdateTrolleyInventry != null)
            {
                OnUpdateTrolleyInventry(inventryInfo);
            }
        }

        public async Task<HttpResponseMessage> UpdateDataAsync(string endpoint, string roomid, string jsonData)
        {
            string url = RestApiAddress + "/" + endpoint + "/" + roomid;

            try
            {
                HttpContent content = new StringContent(jsonData, Encoding.UTF8, "application/json");
                HttpResponseMessage response = await _httpClient.PutAsync(url, content);

                return response;
            }
            catch (Exception ex)
            {
                // Handle exceptions here
                return null;
            }
        }

        public async Task<HttpResponseMessage> AddDataSync(string endpoint, string jsonData)
        {
            string url = RestApiAddress + "/" + endpoint;


            try
            {
                HttpContent content = new StringContent(jsonData, Encoding.UTF8, "application/json");
                content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                HttpResponseMessage response = await _httpClient.PostAsync(url, content);

                return response;
            }
            catch (Exception ex)
            {
                // Handle exceptions here
                return null;
            }
        }
    }
}



